"""Local, reversible download sorting. Preview by default; --apply moves files."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import stat
import tempfile
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

STATE = ".download-organizer"
TYPES = {
    "문서": ".pdf .doc .docx .odt .rtf .txt .md .hwp .hwpx .ppt .pptx .epub",
    "스프레드시트": ".xls .xlsx .xlsm .ods .csv .tsv",
    "이미지": ".jpg .jpeg .png .gif .webp .heic .heif .bmp .tif .tiff .svg .avif",
    "동영상": ".mp4 .mov .mkv .avi .webm .m4v .wmv",
    "음악": ".mp3 .m4a .wav .flac .aac .ogg .opus",
    "압축파일": ".zip .7z .rar .gz .bz2 .xz .tar .tgz",
    "설치파일": ".exe .msi .dmg .pkg .deb .rpm .appimage .apk",
    "코드": ".py .js .ts .html .css .ipynb .sh .sql",
}
EXTENSIONS = {extension: category for category, extensions in TYPES.items() for extension in extensions.split()}
TEMPORARY = {".crdownload", ".part", ".partial", ".download", ".filepart", ".tmp", ".temp"}


def digest(path: Path) -> str:
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError(f"일반 파일이 아닙니다: {path.name}")
    checksum = hashlib.sha256()
    with path.open("rb") as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b""):
            checksum.update(chunk)
    after = path.lstat()
    if (before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns):
        raise ValueError(f"작업 도중 변경된 파일입니다: {path.name}")
    return checksum.hexdigest()


def safe_path(root: Path, relative: str) -> Path:
    part = Path(relative)
    if part.is_absolute() or not part.parts or any(p in ("..", ".") for p in part.parts):
        raise ValueError("기록에 허용되지 않는 경로가 있습니다.")
    current = root
    for name in part.parts:
        current = current / name
        if current.is_symlink():
            raise ValueError(f"심볼릭 링크는 처리하지 않습니다: {relative}")
    return current


def choose_target(root: Path, relative: Path, reserved: set[str]) -> str:
    candidate = relative
    index = 2
    while True:
        target = safe_path(root, str(candidate))
        # Casefold also prevents name collisions on case-insensitive volumes.
        siblings = {p.name.casefold() for p in target.parent.iterdir()} if target.parent.is_dir() else set()
        if str(candidate).casefold() not in reserved and candidate.name.casefold() not in siblings:
            reserved.add(str(candidate).casefold())
            return str(candidate)
        candidate = relative.with_name(f"{relative.stem} ({index}){relative.suffix}")
        index += 1


def plan(root: Path) -> dict:
    files, skipped, folders = [], [], []
    for path in root.iterdir():
        if path.name in (STATE, STATE + ".lock"):
            continue
        if path.is_symlink():
            skipped.append({"name": path.name, "reason": "심볼릭 링크"})
        elif path.is_dir():
            folders.append(path.name)
        elif (path.name.startswith((".", "~$", "~")) or path.suffix.lower() in TEMPORARY
              or not path.is_file()):
            skipped.append({"name": path.name, "reason": "숨김·임시·다운로드 중 또는 특수 파일"})
        else:
            files.append(path)
    # Prefer the original-looking name over '(1)' / '(2)' copies.
    files.sort(key=lambda p: (bool(re.search(r"\(\d+\)(?=\.[^.]+$)", p.name)), len(p.name), p.name.casefold()))
    known, reserved, operations = {}, set(), []
    for path in files:
        checksum = digest(path)
        category = EXTENSIONS.get(path.suffix.lower(), "기타")
        duplicate = known.get(checksum)
        relative = Path("중복_보관", category, path.name) if duplicate else Path(category, path.name)
        destination = choose_target(root, relative, reserved)
        operations.append({"source": path.name, "destination": destination, "sha256": checksum,
                           "duplicate_of": duplicate, "status": "pending"})
        if not duplicate:
            known[checksum] = destination
    return {"version": 1, "id": datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:8],
            "status": "planned", "operations": operations, "skipped": skipped,
            "untouched_folders": folders, "created_directories": []}


def write_record(path: Path, record: dict) -> None:
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, delete=False) as file:
            temporary = Path(file.name)
            json.dump(record, file, ensure_ascii=False, indent=2)
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


@contextmanager
def locked(root: Path):
    path = root / (STATE + ".lock")
    with path.open("x", encoding="utf-8") as file:
        file.write("download organizer is running\n")
    try:
        yield
    finally:
        path.unlink()


def move_without_overwrite(source: Path, target: Path, expected: str) -> None:
    if target.exists() or target.is_symlink():
        raise ValueError(f"대상 파일이 이미 있습니다: {target.name}")
    if digest(source) != expected:
        raise ValueError(f"계획 이후 파일 내용이 변경되었습니다: {source.name}")
    # Both locations are on the same volume. Link creation fails atomically if
    # target exists; unlink only after the second name was successfully created.
    os.link(source, target, follow_symlinks=False)
    try:
        source.unlink()
    except OSError:
        target.unlink()
        raise


def apply(root: Path, record: dict) -> Path | None:
    if not record["operations"]:
        return None
    state = safe_path(root, STATE)
    state.mkdir(exist_ok=True)
    log = state / (record["id"] + ".json")
    if log.exists():
        raise ValueError("같은 실행 기록이 이미 있습니다.")
    write_record(log, record)
    for operation in record["operations"]:
        source = safe_path(root, operation["source"])
        target = safe_path(root, operation["destination"])
        missing = []
        parent = target.parent
        while parent != root and not parent.exists():
            missing.append(parent)
            parent = parent.parent
        for folder in reversed(missing):
            record["created_directories"].append(str(folder.relative_to(root)))
            write_record(log, record)
            folder.mkdir()
        move_without_overwrite(source, target, operation["sha256"])
        operation["status"] = "moved"
        write_record(log, record)
    record["status"] = "complete"
    write_record(log, record)
    return log


def undo(root: Path) -> int:
    state = safe_path(root, STATE)
    records = []
    if state.is_dir():
        for path in sorted(state.glob("*.json"), reverse=True):
            if path.is_symlink():
                raise ValueError("기록 파일이 심볼릭 링크입니다.")
            record = json.loads(path.read_text(encoding="utf-8"))
            if record.get("status") != "undone":
                records.append((path, record))
    if not records:
        raise ValueError("되돌릴 정리 기록이 없습니다.")
    log, record = records[0]
    if record.get("version") != 1:
        raise ValueError("지원하지 않는 정리 기록입니다.")
    restore = []
    # Validate the entire undo before moving any file.
    for operation in reversed(record["operations"]):
        source = safe_path(root, operation["source"])
        target = safe_path(root, operation["destination"])
        expected = operation["sha256"]
        if source.parent != root or target.parent == root or target.is_relative_to(state):
            raise ValueError("허용되지 않는 복원 경로입니다.")
        if source.exists():
            if target.exists() or digest(source) != expected:
                raise ValueError(f"원래 위치가 사용 중이거나 내용이 바뀌었습니다: {source.name}")
        elif not target.is_file() or digest(target) != expected:
            raise ValueError(f"이동된 파일이 없거나 내용이 바뀌었습니다: {target.name}")
        else:
            restore.append((operation, target, source, expected))
    for operation, target, source, expected in restore:
        move_without_overwrite(target, source, expected)
        operation["status"] = "restored"
        write_record(log, record)
    for relative in reversed(record["created_directories"]):
        folder = safe_path(root, relative)
        if folder == state or folder.parent == folder:
            raise ValueError("허용되지 않는 폴더 경로입니다.")
        try:
            folder.rmdir()  # Only directories created by this run, only if empty.
        except OSError:
            pass
    record["status"] = "undone"
    write_record(log, record)
    return len(restore)


def main():
    parser = argparse.ArgumentParser(description="다운로드 파일 분류·동일 내용 중복 보관 (기본: 미리보기)")
    parser.add_argument("folder", type=Path, help="정리할 폴더")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--apply", action="store_true", help="미리보기 대신 실제로 이동")
    mode.add_argument("--undo", action="store_true", help="가장 최근 정리를 되돌리기")
    args = parser.parse_args()
    if args.folder.is_symlink():
        parser.error("심볼릭 링크 폴더는 지정할 수 없습니다.")
    root = args.folder.resolve()
    if not root.is_dir():
        parser.error("존재하는 폴더를 지정해 주세요.")
    try:
        if args.undo:
            with locked(root):
                count = undo(root)
            print(f"복원 완료: {count}개 파일")
            return
        if args.apply:
            with locked(root):
                record = plan(root)
                log = apply(root, record)
        else:
            record, log = plan(root), None
        for operation in record["operations"]:
            reason = " [동일 내용 중복 보관]" if operation["duplicate_of"] else ""
            print(f"{operation['source']} → {operation['destination']}{reason}")
        duplicates = sum(bool(op["duplicate_of"]) for op in record["operations"])
        print(f"{'정리 완료' if args.apply else '미리보기'}: 이동 {len(record['operations'])}개 (중복 보관 {duplicates}개 포함), "
              f"건너뜀 {len(record['skipped'])}개, 기존 폴더 유지 {len(record['untouched_folders'])}개")
        if log:
            print(f"되돌리기 기록: {log.relative_to(root)}")
    except (OSError, ValueError, KeyError, TypeError) as exc:
        parser.exit(1, f"작업 중단: {exc}\n일부 이동이 완료됐다면 --undo로 복원할 수 있습니다.\n")


if __name__ == "__main__":
    main()
