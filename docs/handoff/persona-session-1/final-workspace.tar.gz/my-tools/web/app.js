"use strict";
let data = null;
let selectedCategory = null;
let sessionTimer = null;
const $ = (id) => document.getElementById(id);
const number = new Intl.NumberFormat("ko-KR");
const money = (value) => `${number.format(value)}원`;
const names = {"식비·배달":"식", "카페·간식":"☕", "쇼핑":"쇼", "식료품·생활":"생", "교통·차량":"교", "의료·건강":"의", "문화·구독":"문", "여행·숙박":"여", "기타":"·"};

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function render() {
  if (!data) return;
  const month = $("month").value;
  const summary = data.months.find((item) => item.month === month);
  if (!summary) {
    $("net").textContent = "0원";
    $("approved").textContent = "0원";
    $("cancelled").textContent = "0원";
    $("net-note").textContent = "저장된 내역이 없어요";
    $("categories").replaceChildren();
    $("transactions").replaceChildren();
    $("count").textContent = "0건";
    $("notices").replaceChildren();
    $("reconciliation").textContent = "";
    $("empty").hidden = false;
    return;
  }
  $("net").textContent = money(summary.total);
  $("approved").textContent = money(summary.recorded_approved);
  $("cancelled").textContent = money(summary.recorded_cancelled);
  $("net-note").textContent = `전체 ${summary.recorded_count}건 · 집계 ${summary.count}건${summary.fx_estimated_count ? " · 환산 추정액 포함" : ""}`;
  $("reconciliation").textContent = `전체 내역 ${money(summary.recorded_total)} − 제외 순금액 (${money(summary.excluded_amount)}) = ${money(summary.total)}`;
  const notices = [];
  if (summary.excluded_count) notices.push(element("span", "notice", `집계 제외 ${summary.excluded_count}건 · ${money(summary.excluded_amount)}`));
  if (summary.fx_estimated_count) notices.push(element("span", "notice estimate", `달러 환산 추정 ${summary.fx_estimated_count}건 · 실제 청구액과 다를 수 있어요`));
  if (summary.category_review_count) notices.push(element("span", "notice", `분류 확인 필요 ${summary.category_review_count}건`));
  if (summary.pending_review_count) notices.push(element("span", "notice estimate", `내역 확인 메모 ${summary.pending_review_count}건`));
  $("notices").replaceChildren(...notices);

  const categories = Object.entries(summary.categories).filter(([, value]) => value !== 0).sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]));
  const maximum = Math.max(...categories.map(([, value]) => Math.abs(value)), 1);
  const buttons = categories.map(([name, value]) => {
    const button = element("button", `category-button${selectedCategory === name ? " selected" : ""}`);
    button.type = "button";
    button.setAttribute("aria-pressed", String(selectedCategory === name));
    const row = element("span", "category-row");
    const label = element("span", "category-name");
    label.append(element("span", "category-dot"), document.createTextNode(name));
    row.append(label, element("span", "category-value", money(value)));
    const bar = element("progress", "category-bar");
    bar.max = maximum;
    bar.value = Math.abs(value);
    bar.setAttribute("aria-label", `${name} ${money(value)}`);
    button.append(row, bar);
    button.addEventListener("click", () => {selectedCategory = selectedCategory === name ? null : name; render();});
    return button;
  });
  $("categories").replaceChildren(...buttons);
  if (!buttons.length) $("categories").append(element("p", "small muted", "카테고리별 순지출이 없어요."));
  $("all-categories").hidden = !selectedCategory;
  const search = $("search").value.trim().toLocaleLowerCase("ko-KR");
  const transactions = data.transactions.filter((row) => row.date.startsWith(month + "-")
    && (!selectedCategory || row.category === selectedCategory)
    && (!search || row.merchant.toLocaleLowerCase("ko-KR").includes(search))
    && ($("show-excluded").checked || !row.excluded));
  $("count").textContent = `${transactions.length}건`;
  const filtered = selectedCategory || search || !$("show-excluded").checked;
  $("filter-note").hidden = !filtered;
  $("filter-note").textContent = filtered ? `${selectedCategory ? selectedCategory + " · " : ""}목록만 필터링합니다. 위 합계는 선택 월 전체 기준입니다.` : "";
  $("transactions").replaceChildren(...transactions.map(transaction));
  $("empty").hidden = transactions.length !== 0;
}

function transaction(row) {
  const details = element("details", `transaction${row.cancelled ? " refund" : ""}${row.excluded ? " excluded" : ""}`);
  const header = element("summary");
  const icon = element("span", "transaction-icon", names[row.category] || "·");
  icon.setAttribute("aria-hidden", "true");
  const main = element("span", "transaction-main");
  const meta = element("span", "transaction-meta");
  meta.append(element("span", "", row.date.replace("T", " ").slice(5)), element("span", "", row.card), element("span", "", row.category));
  main.append(element("span", "merchant", row.merchant), meta);
  const right = element("span", "transaction-right");
  right.append(element("span", "transaction-amount", money(row.amount)));
  const tags = element("span", "tags");
  if (row.excluded) tags.append(element("span", "tag", "집계 제외"));
  if (row.cancelled) tags.append(element("span", "tag refund", "취소"));
  if (row.fx_estimated) tags.append(element("span", "tag estimate", "환산 추정"));
  if (row.category_method === "확인 필요") tags.append(element("span", "tag", "분류 확인"));
  if (row.review_note) tags.append(element("span", "tag estimate", "확인 메모"));
  right.append(tags);
  header.append(icon, main, right);
  const info = element("div", "transaction-detail");
  info.append(element("p", "", `분류: ${row.category_method}`));
  info.append(element("p", "", `이 내역의 집계 반영액: ${money(row.excluded ? 0 : row.amount)}`));
  if (row.excluded) info.append(element("p", "", `제외 사유: ${row.exclusion_reason}`));
  if (row.review_note) info.append(element("p", "", `확인 메모: ${row.review_note}`));
  if (row.original_currency === "USD") {
    info.append(element("p", "", `원거래 USD ${row.original_amount} · 1 USD = ${row.fx_rate}원`));
    info.append(element("p", "", `환율 기준일 ${row.fx_date}${row.fx_estimated ? " · 참고 환율에 의한 추정액, 수수료 미포함" : " · 원화 금액 직접 입력"}`));
  }
  details.append(header, info);
  return details;
}

async function load() {
  $("refresh").disabled = true;
  $("status").className = "status";
  $("status").textContent = "컴퓨터에서 최신 가계부를 불러오고 있어요.";
  try {
    const response = await fetch("/api/ledger", {credentials:"same-origin", cache:"no-store"});
    if (response.status === 401) {location.replace("/login"); return;}
    if (!response.ok) throw new Error("unavailable");
    data = await response.json();
    if (data.schema_version !== 2) throw new Error("restart_required");
    clearTimeout(sessionTimer);
    sessionTimer = setTimeout(() => {data = null; document.body.replaceChildren(); location.replace("/login");}, 1800 * 1000);
    const previous = $("month").value;
    const now = new Date();
    const current = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
    const options = data.months.map((item) => {
      const option = element("option", "", `${item.month.slice(0,4)}년 ${Number(item.month.slice(5))}월`);
      option.value = item.month;
      return option;
    });
    $("month").replaceChildren(...options);
    $("month").disabled = !options.length;
    const available = data.months.map((item) => item.month);
    $("month").value = available.includes(previous) ? previous : available.includes(current) ? current : available[0] || "";
    if (selectedCategory && !data.months.some((item) => item.categories[selectedCategory])) selectedCategory = null;
    $("updated").textContent = `${new Date(data.updated_at).toLocaleString("ko-KR")}에 불러옴 · 내역 버전 ${data.revision}`;
    $("status").textContent = options.length ? "내역을 누르면 분류와 환산 정보를 볼 수 있어요." : "저장된 거래가 없어요. 컴퓨터 앱에서 내역을 추가하고 전체 저장을 눌러 주세요.";
    render();
  } catch (error) {
    $("status").className = "status error";
    $("status").textContent = error.message === "restart_required"
      ? "웹 서버를 종료하고 다시 실행한 뒤 새로고침해 주세요. 이전 버전의 서버가 실행 중입니다."
      : "가계부를 불러오지 못했어요. 컴퓨터에서 JSON 파일과 서버를 확인하고 새로고침해 주세요.";
  } finally {
    $("refresh").disabled = false;
  }
}

$("month").addEventListener("change", () => {selectedCategory = null; $("search").value = ""; render();});
$("search").addEventListener("input", render);
$("show-excluded").addEventListener("change", render);
$("all-categories").addEventListener("click", () => {selectedCategory = null; render();});
$("refresh").addEventListener("click", load);
$("logout").addEventListener("click", async () => {
  try {
    const response = await fetch("/logout", {method:"POST", body:new URLSearchParams(), credentials:"same-origin", cache:"no-store"});
    if (!response.ok) throw new Error("logout failed");
    data = null;
    document.body.replaceChildren();
    location.replace("/login");
  } catch (_) {
    $("status").textContent = "로그아웃에 실패했어요. 연결을 확인한 뒤 다시 눌러 주세요.";
  }
});
window.addEventListener("pageshow", (event) => {
  if (event.persisted) {data = null; $("transactions").replaceChildren(); load();}
});
load();
