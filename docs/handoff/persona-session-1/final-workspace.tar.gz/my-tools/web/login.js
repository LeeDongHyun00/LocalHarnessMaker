"use strict";
const form = document.querySelector("#login-form");
form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = document.querySelector("#login-button");
  const input = document.querySelector("#password");
  const error = document.querySelector("#login-error");
  button.disabled = true;
  error.textContent = "";
  try {
    const body = new URLSearchParams({password: input.value});
    input.value = "";
    const response = await fetch("/login", {method: "POST", body, credentials: "same-origin", cache: "no-store"});
    if (response.ok) {
      location.replace("/");
      return;
    }
    error.textContent = response.status === 429 ? "시도가 너무 많아요. 1분 뒤 다시 입력해 주세요." : "비밀번호를 확인해 주세요.";
  } catch (_) {
    error.textContent = "로컬 서버에 연결할 수 없어요. 이 컴퓨터에서 서버가 실행 중인지 확인해 주세요.";
  } finally {
    button.disabled = false;
  }
});
