"""Offline USD conversion using existing local rates or an imported XML file."""
from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path
from xml.etree import ElementTree as ET

URL = "https://www.ecb.europa.eu/stats/eurofxref/eurofxref-hist.xml"
CACHE_PATH = Path(__file__).with_name(".fx-cache") / "ecb-usd-krw.json"
USD = re.compile(r"(?:\bUSD|US\$|미화)\s*(\d[\d,]*(?:\.\d{1,2})?)(?![\d.,])|(?<![\d.,])(\d[\d,]*(?:\.\d{1,2})?)\s*(?:USD\b|달러)", re.I)


def usd_amount(text: str) -> Decimal | None:
    matches = list(USD.finditer(text))
    if not matches:
        return None
    if len(matches) != 1:
        raise ValueError("달러 금액을 하나로 확정할 수 없습니다.")
    number = next(group for group in matches[0].groups() if group is not None)
    if not re.fullmatch(r"(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d{1,2})?", number):
        raise ValueError("올바른 USD 금액 형식이 아닙니다.")
    amount = Decimal(number.replace(",", ""))
    if amount <= 0:
        raise ValueError("달러 결제금액은 0보다 커야 합니다.")
    return amount


@dataclass
class RateBook:
    rates: dict[str, str]
    fetched_on: str
    notice: str = field(default="", compare=False)

    def rate_for(self, transaction_date: str) -> tuple[Decimal, str]:
        target = date.fromisoformat(transaction_date)
        if target > date.today():
            raise ValueError("미래 거래일의 환율은 아직 알 수 없습니다. 연도를 확인해 주세요.")
        available = [day for day in self.rates if day <= transaction_date]
        if not available:
            raise ValueError("해당 거래일 이전의 환율 자료가 없습니다.")
        day = max(available)
        if (target - date.fromisoformat(day)).days > 7:
            raise ValueError("거래일과 가까운 환율이 없습니다. 환율 자료를 갱신해 주세요.")
        return Decimal(self.rates[day]), day


def parse_ecb(data: bytes) -> RateBook:
    root = ET.fromstring(data)
    rates = {}
    for element in root.iter():
        day = element.get("time")
        if day is None:
            continue
        date.fromisoformat(day)
        quotes = {child.get("currency"): child.get("rate") for child in element}
        if "USD" not in quotes or "KRW" not in quotes:
            continue
        usd, krw = Decimal(quotes["USD"]), Decimal(quotes["KRW"])
        if not usd.is_finite() or not krw.is_finite() or usd <= 0 or krw <= 0:
            raise ValueError("공개 환율 자료의 값이 유효하지 않습니다.")
        rates[day] = str((krw / usd).quantize(Decimal("0.000001"), rounding=ROUND_HALF_UP))
    if not rates:
        raise ValueError("공개 자료에서 USD/KRW 환율을 찾지 못했습니다.")
    return RateBook(rates, datetime.now(timezone.utc).date().isoformat())


def read_cache(path: Path) -> RateBook:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict) or data.get("version") != 1 or data.get("source") != URL or not isinstance(data.get("rates"), dict):
        raise ValueError("환율 캐시 형식이 올바르지 않습니다.")
    date.fromisoformat(data["fetched_on"])
    for day, rate in data["rates"].items():
        date.fromisoformat(day)
        number = Decimal(rate)
        if not number.is_finite() or number <= 0:
            raise ValueError("유효하지 않은 캐시 환율입니다.")
    if not data["rates"]:
        raise ValueError("환율 캐시가 비어 있습니다.")
    return RateBook(data["rates"], data["fetched_on"])


def load_rates(*, offline: bool = True, cache_path: Path = CACHE_PATH) -> RateBook:
    if not offline:
        raise ValueError("외부 환율 조회는 차단되어 있습니다. 로컬 환율 XML을 가져와 주세요.")
    try:
        return read_cache(cache_path)
    except (OSError, ValueError, TypeError, KeyError, InvalidOperation):
        raise ValueError("저장된 유효한 환율이 없습니다. 로컬 환율 XML을 가져오거나 원화 청구액을 직접 입력해 주세요.") from None


def import_rates(path: Path, *, cache_path: Path = CACHE_PATH) -> RateBook:
    from local_io import atomic_write
    with path.open("rb") as file:
        data = file.read(25_000_001)
    if len(data) > 25_000_000:
        raise ValueError("환율 자료가 허용 크기를 초과했습니다.")
    book = parse_ecb(data)
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    atomic_write(str(cache_path), json.dumps({"version": 1, "source": URL, "fetched_on": book.fetched_on,
                                            "rates": book.rates}).encode("utf-8"))
    return book


def convert_usd(amount: Decimal, transaction_date: str, book: RateBook) -> tuple[int, str, str]:
    rate, day = book.rate_for(transaction_date)
    converted = int((amount * rate).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    if converted <= 0:
        raise ValueError("환산액이 1원 미만입니다. 직접 확인해 주세요.")
    return converted, str(rate), day
def main():
    parser = argparse.ArgumentParser(description="인터넷 접속 없이 로컬 ECB 환율 XML 가져오기")
    parser.add_argument("--import-xml", required=True, type=Path, help="컴퓨터에 있는 환율 XML 경로")
    args = parser.parse_args()
    try:
        book = import_rates(args.import_xml)
    except (OSError, ValueError, ET.ParseError, InvalidOperation) as exc:
        parser.exit(1, f"가져오기 실패: {exc}\n")
    print(f"로컬 환율 {len(book.rates)}일치 가져오기 완료 · 마지막 기준일 {max(book.rates)}")


if __name__ == "__main__":
    main()
