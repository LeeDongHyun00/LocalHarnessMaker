"""Optional Chromium end-to-end check. Uses synthetic data and temporary files."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import asyncio
import hashlib
import secrets
import tempfile
import threading
from dataclasses import replace

from playwright.async_api import async_playwright, expect

from exchange_rates import RateBook
from ledger import load_ledger, parse_message, save_ledger, summarize
from web_app import Authentication, LedgerServer, tls_context


async def main():
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        ledger = root / "ledger.json"
        rows = []
        for index, (merchant, amount) in enumerate((("스타벅스 강남점", 12000), ("쿠팡", 45800), ("배달의민족", 33000),
                                                   ("GS25", 4500), ("테스트주유소", 70000), ("카카오T", 13200))):
            row = parse_message(f"현대카드 승인 {amount:,}원 2025/10/{index+3:02d} 12:00 {merchant}", 2026)
            rows.append(row)
        rows.append(replace(rows[0], id="refund", amount=-12000, cancelled=True))
        rows[4] = replace(rows[4], excluded=True, exclusion_reason="결제 상태 확인 대기")
        rows.append(parse_message("현대카드 해외승인 USD 15.99 2025/10/05 09:00 NETFLIX", 2026,
                                  rates=RateBook({"2025-10-03": "1320.25"}, "2025-10-03")))
        rows.append(parse_message("현대카드 승인 14,900원 2025/11/01 12:00 넷플릭스", 2026))
        save_ledger(str(ledger), rows)
        password = secrets.token_urlsafe(24)
        context, _ = tls_context(root / "tls", ["127.0.0.1"])
        server = LedgerServer(("127.0.0.1", 0), ledger, Authentication(password), context, {"127.0.0.1"})
        thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": .05}, daemon=True)
        thread.start()
        base = f"https://127.0.0.1:{server.server_port}"
        try:
            async with async_playwright() as playwright:
                browser = await playwright.chromium.launch(args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-background-networking"])
                client = await browser.new_context(viewport={"width": 390, "height": 844}, ignore_https_errors=True, is_mobile=True, has_touch=True)
                external = []

                async def route(request):
                    if request.request.url.startswith(base + "/"):
                        await request.continue_()
                    else:
                        external.append(request.request.url)
                        await request.abort()

                await client.route("**/*", route)
                page = await client.new_page()
                errors = []
                page.on("pageerror", lambda error: errors.append(str(error)))
                await page.goto(base)
                await expect(page.locator("#login-form")).to_be_visible()
                assert (await client.request.get(base + "/api/ledger")).status == 401
                await page.locator("#password").fill("wrong-password")
                await page.locator("#login-button").click()
                await expect(page.locator("#login-error")).not_to_be_empty()
                await page.locator("#password").fill(password)
                await page.locator("#login-button").click()
                await expect(page.locator("#month")).to_be_enabled()
                await page.locator("#month").select_option("2025-10")
                await expect(page.locator("#net")).to_have_text("117,611원")
                await expect(page.locator("#approved")).to_have_text("199,611원")
                await expect(page.locator("#cancelled")).to_have_text("12,000원")
                await expect(page.locator("#reconciliation")).to_have_text("전체 내역 187,611원 − 제외 순금액 (70,000원) = 117,611원")
                assert await page.locator(".transaction").count() == 8
                assert await page.locator(".excluded").count() == 1
                await page.locator("#search").fill("NETFLIX")
                await expect(page.locator(".transaction")).to_have_count(1)
                await expect(page.locator("#net")).to_have_text("117,611원")
                await expect(page.locator("#filter-note")).to_contain_text("선택 월 전체 기준")
                await page.locator(".transaction summary").click()
                await expect(page.locator(".transaction-detail")).to_contain_text("USD 15.99")
                await expect(page.locator(".transaction-detail")).to_contain_text("2025-10-03")
                await page.locator("#search").fill("")
                await page.locator("#show-excluded").uncheck()
                await expect(page.locator(".transaction")).to_have_count(7)
                await page.locator("#show-excluded").check()
                await page.get_by_role("button", name="문화·구독").click()
                await expect(page.locator(".transaction")).to_have_count(1)
                await page.locator("#all-categories").click()
                await expect(page.locator(".transaction")).to_have_count(8)
                for width, height in ((390, 844), (360, 780), (1280, 900)):
                    await page.set_viewport_size({"width": width, "height": height})
                    assert await page.evaluate("document.documentElement.scrollWidth <= innerWidth"), f"Overflow at {width}px"
                    await page.screenshot(path=f"/tmp/ledger-web-{width}.png", full_page=True)
                await page.locator("#month").select_option("2025-11")
                await expect(page.locator("#net")).to_have_text("14,900원")
                assert await page.evaluate("localStorage.length === 0 && sessionStorage.length === 0")
                cookies = await client.cookies()
                assert len(cookies) == 1 and cookies[0]["secure"] and cookies[0]["httpOnly"] and cookies[0]["sameSite"] == "Strict"
                # A malicious-looking name stays literal text, including after refresh.
                bad = replace(rows[0], merchant='<img src=x onerror="window.__xss=1">')
                save_ledger(str(ledger), [bad])
                await page.locator("#refresh").click()
                await expect(page.locator("#net")).to_have_text("12,000원")
                await expect(page.locator(".merchant")).to_have_text(bad.merchant)
                assert await page.evaluate("window.__xss === undefined")
                assert await page.locator(".merchant img").count() == 0
                save_ledger(str(ledger), [])
                await page.locator("#refresh").click()
                await expect(page.locator("#net")).to_have_text("0원")
                await expect(page.locator("#empty")).to_be_visible()
                await page.locator("#logout").click()
                await expect(page.locator("#login-form")).to_be_visible()
                assert (await client.request.get(base + "/api/ledger")).status == 401
                # Read the user's ledger only for final totals verification, never screenshots.
                real = Path(__file__).resolve().parents[1] / "카드내역.json"
                if real.exists():
                    before = hashlib.sha256(real.read_bytes()).hexdigest()
                    server.ledger = real
                    await page.locator("#password").fill(password)
                    await page.locator("#login-button").click()
                    await expect(page.locator("#month")).to_be_enabled()
                    await page.locator("#month").select_option("2026-10")
                    expected = summarize(load_ledger(str(real)), "2026-10")["total"]
                    await expect(page.locator("#net")).to_have_text(f"{expected:,}원")
                    assert hashlib.sha256(real.read_bytes()).hexdigest() == before
                assert not errors, errors
                assert not external, "Unexpected external requests"
                await browser.close()
                print("PASS: HTTPS login, logout, filters, month switch, excluded/FX details, live refresh, empty state, XSS, 360/390/1280px, actual totals; no external requests")
        finally:
            server.shutdown()
            server.server_close()
            thread.join()


if __name__ == "__main__":
    asyncio.run(main())
