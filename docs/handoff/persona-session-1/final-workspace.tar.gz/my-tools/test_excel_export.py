import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch
from xml.etree import ElementTree as ET
from zipfile import ZipFile

from excel_export import SHEET_NS, export_xlsx
from ledger import parse_message

NS = {"s": SHEET_NS}


def cell_value(sheet, address):
    cell = sheet.find(f".//s:c[@r='{address}']", NS)
    if cell.get("t") == "inlineStr":
        return cell.find("s:is/s:t", NS).text
    return int(cell.find("s:v", NS).text)


class ExcelExportTests(unittest.TestCase):
    def setUp(self):
        self.october = parse_message("우리(9876)체크승인 김*수 5,100원 10/12 09:15 GS25테스트점 잔액999,999원", 2026)
        self.cancel = parse_message("신한카드 승인취소 1,000원 10/13 10:00 GS25테스트점", 2026)
        self.november = parse_message("현대카드 승인 9,900원 11/01 12:00 넷플릭스", 2026)

    def test_month_sheets_totals_categories_and_numeric_transactions(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "ledger.xlsx")
            export_xlsx(path, [self.november, self.cancel, self.october], review_count=2)
            with ZipFile(path) as archive:
                self.assertIsNone(archive.testzip())
                workbook = ET.fromstring(archive.read("xl/workbook.xml"))
                self.assertEqual([s.get("name") for s in workbook.find("s:sheets", NS)], ["2026-10", "2026-11"])
                october = ET.fromstring(archive.read("xl/worksheets/sheet1.xml"))
                november = ET.fromstring(archive.read("xl/worksheets/sheet2.xml"))
                self.assertEqual([cell_value(october, f"B{i}") for i in (3, 4, 5)], [5100, 1000, 4100])
                self.assertEqual(cell_value(october, "B11"), 4100)  # 식료품·생활
                self.assertEqual(cell_value(october, "B19"), "우리체크카드")
                self.assertEqual(cell_value(october, "D19"), 5100)
                self.assertEqual(cell_value(october, "D20"), -1000)
                self.assertEqual(cell_value(october, "F20"), "취소")
                self.assertEqual(cell_value(november, "B5"), 9900)
                self.assertEqual(cell_value(november, "C19"), "넷플릭스")
                self.assertEqual(october.find("s:autoFilter", NS).get("ref"), "A18:Q20")
                self.assertIn("2건", cell_value(october, "A2"))
                for name in archive.namelist():
                    self.assertNotIn("김*수", archive.read(name).decode("utf-8"))
                self.assertFalse(any("externalLink" in name for name in archive.namelist()))

    def test_text_is_literal_xml_escaped_and_illegal_controls_removed(self):
        row = replace(self.october, merchant='=HYPERLINK("https://example.invalid") & <가게>\x00')
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "ledger.xlsx")
            export_xlsx(path, [row])
            with ZipFile(path) as archive:
                sheet = ET.fromstring(archive.read("xl/worksheets/sheet1.xml"))
                self.assertEqual(cell_value(sheet, "C19"), row.merchant.replace("\x00", ""))
                self.assertEqual(sheet.findall(".//s:f", NS), [])

    def test_exclusion_is_visible_but_does_not_enter_totals(self):
        pending = replace(self.october, excluded=True, exclusion_reason="확인 대기")
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "ledger.xlsx")
            export_xlsx(path, [pending, self.cancel])
            with ZipFile(path) as archive:
                sheet = ET.fromstring(archive.read("xl/worksheets/sheet1.xml"))
                self.assertEqual(cell_value(sheet, "B3"), 5100)
                self.assertEqual(cell_value(sheet, "B5"), -1000)
                self.assertEqual(cell_value(sheet, "E3"), 1)
                self.assertEqual(cell_value(sheet, "E4"), 5100)
                self.assertEqual(cell_value(sheet, "D19"), 5100)
                self.assertEqual(cell_value(sheet, "F19"), "승인")
                self.assertEqual(cell_value(sheet, "G19"), 0)
                self.assertEqual(cell_value(sheet, "H19"), "제외")
                self.assertEqual(cell_value(sheet, "I19"), "확인 대기")
                self.assertEqual(cell_value(sheet, "G20"), -1000)

    def test_distinct_years_have_distinct_sheets(self):
        row = replace(self.october, date="2025-10-12T09:15")
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "ledger.xlsx")
            export_xlsx(path, [self.october, row])
            with ZipFile(path) as archive:
                workbook = ET.fromstring(archive.read("xl/workbook.xml"))
                self.assertEqual([s.get("name") for s in workbook.find("s:sheets", NS)], ["2025-10", "2026-10"])

    def test_empty_export_does_not_overwrite_existing_file(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "ledger.xlsx"
            path.write_bytes(b"previous")
            with self.assertRaises(ValueError):
                export_xlsx(str(path), [])
            self.assertEqual(path.read_bytes(), b"previous")

    def test_write_failure_preserves_existing_workbook_and_cleans_temp(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "ledger.xlsx"
            export_xlsx(str(path), [self.october])
            previous = path.read_bytes()
            with patch("excel_export.ZipFile.writestr", side_effect=OSError("disk error")):
                with self.assertRaises(OSError):
                    export_xlsx(str(path), [self.november])
            self.assertEqual(path.read_bytes(), previous)
            self.assertEqual(list(Path(directory).iterdir()), [path])


if __name__ == "__main__":
    unittest.main()
