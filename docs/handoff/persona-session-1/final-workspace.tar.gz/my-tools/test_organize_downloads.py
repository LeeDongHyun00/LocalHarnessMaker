import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from organize_downloads import STATE, apply, digest, locked, plan, undo


class OrganizerTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)

    def put(self, name, content):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
        return path

    def snapshot(self):
        return {str(p.relative_to(self.root)): p.read_bytes() for p in self.root.rglob('*')
                if p.is_file() and STATE not in p.parts}

    def test_preview_leaves_files_unchanged_and_uses_content_not_size(self):
        self.put('report.pdf', b'aaaa')
        self.put('report(1).pdf', b'aaaa')
        self.put('report_final.pdf', b'bbbb')
        before = self.snapshot()
        record = plan(self.root)
        self.assertEqual(self.snapshot(), before)
        self.assertFalse((self.root / STATE).exists())
        self.assertEqual(sum(bool(op['duplicate_of']) for op in record['operations']), 1)
        original = next(op for op in record['operations'] if op['source'] == 'report.pdf')
        self.assertIsNone(original['duplicate_of'])

    def test_apply_and_undo_preserve_all_bytes_and_existing_folders(self):
        for name, data in [('a.JPG', b'photo'), ('a(1).JPG', b'photo'), ('data.csv', b'csv'),
                           ('notes.txt', b'text'), ('old/memo.txt', b'keep'),
                           ('.DS_Store', b'hidden'), ('~$report.docx', b'lock'), ('movie.mp4.crdownload', b'partial')]:
            self.put(name, data)
        before = self.snapshot()
        with locked(self.root):
            record = plan(self.root)
            log = apply(self.root, record)
        self.assertTrue(log.exists())
        self.assertEqual((self.root / '이미지/a.JPG').read_bytes(), b'photo')
        self.assertEqual((self.root / '중복_보관/이미지/a(1).JPG').read_bytes(), b'photo')
        self.assertEqual((self.root / 'old/memo.txt').read_bytes(), b'keep')
        self.assertEqual(len(record['skipped']), 3)
        with locked(self.root):
            self.assertEqual(undo(self.root), 4)
        self.assertEqual(self.snapshot(), before)
        self.assertFalse((self.root / '이미지').exists())

    def test_existing_file_collision_gets_new_name_and_preserves_existing(self):
        self.put('이미지/photo.png', b'existing')
        self.put('photo.png', b'new')
        record = plan(self.root)
        self.assertEqual(record['operations'][0]['destination'], '이미지/photo (2).png')
        apply(self.root, record)
        self.assertEqual((self.root / '이미지/photo.png').read_bytes(), b'existing')
        undo(self.root)
        self.assertTrue((self.root / '이미지').is_dir())
        self.assertEqual((self.root / 'photo.png').read_bytes(), b'new')

    def test_symlink_files_skipped_and_symlink_destination_rejected(self):
        target = self.put('old/source.txt', b'keep')
        (self.root / 'link.txt').symlink_to(target)
        self.assertEqual(plan(self.root)['skipped'][0]['reason'], '심볼릭 링크')
        (self.root / '문서').symlink_to(self.root / 'old', target_is_directory=True)
        self.put('new.txt', b'new')
        with self.assertRaises(ValueError):
            plan(self.root)
        self.assertEqual(target.read_bytes(), b'keep')

    def test_source_change_after_preview_is_not_moved(self):
        path = self.put('memo.txt', b'first')
        record = plan(self.root)
        path.write_bytes(b'second')
        with self.assertRaises(ValueError):
            apply(self.root, record)
        self.assertEqual(path.read_bytes(), b'second')
        self.assertFalse((self.root / '문서/memo.txt').exists())

    def test_undo_checks_entire_plan_before_moving_anything(self):
        self.put('a.txt', b'a')
        self.put('b.txt', b'b')
        apply(self.root, plan(self.root))
        self.put('a.txt', b'new original location')
        before = self.snapshot()
        with self.assertRaises(ValueError):
            undo(self.root)
        self.assertEqual(self.snapshot(), before)

    def test_partial_failure_can_be_undone(self):
        self.put('a.txt', b'a')
        self.put('b.txt', b'b')
        before = self.snapshot()
        from organize_downloads import move_without_overwrite
        calls = 0

        def interrupted(source, target, expected):
            nonlocal calls
            calls += 1
            if calls == 2:
                raise OSError('simulated interruption')
            move_without_overwrite(source, target, expected)

        with patch('organize_downloads.move_without_overwrite', side_effect=interrupted):
            with self.assertRaises(OSError):
                apply(self.root, plan(self.root))
        self.assertEqual(undo(self.root), 1)
        self.assertEqual(self.snapshot(), before)

    def test_repeated_apply_is_noop_and_lock_prevents_overlap(self):
        self.put('memo.txt', b'memo')
        with locked(self.root):
            with self.assertRaises(FileExistsError):
                with locked(self.root):
                    pass
            apply(self.root, plan(self.root))
        self.assertEqual(plan(self.root)['operations'], [])
        self.assertIsNone(apply(self.root, plan(self.root)))

    def test_changed_sorted_file_blocks_undo(self):
        self.put('memo.txt', b'memo')
        apply(self.root, plan(self.root))
        (self.root / '문서/memo.txt').write_bytes(b'edited')
        with self.assertRaises(ValueError):
            undo(self.root)
        self.assertEqual((self.root / '문서/memo.txt').read_bytes(), b'edited')

    def test_unsupported_link_does_not_remove_source(self):
        source = self.put('memo.txt', b'memo')
        with patch('organize_downloads.os.link', side_effect=OSError('unsupported filesystem')):
            with self.assertRaises(OSError):
                apply(self.root, plan(self.root))
        self.assertEqual(source.read_bytes(), b'memo')


if __name__ == '__main__':
    unittest.main()
