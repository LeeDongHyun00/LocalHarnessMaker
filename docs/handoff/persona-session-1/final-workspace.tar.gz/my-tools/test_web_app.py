import http.client
import importlib.util
import json
import ssl
import tempfile
import threading
import time
import unittest
from pathlib import Path
from urllib.parse import urlencode
from unittest.mock import patch

from ledger import parse_message, save_ledger
from web_app import COOKIE, Authentication, LedgerServer, private_address, snapshot, tls_context


class WebAuthenticationTests(unittest.TestCase):
    def test_password_and_expired_session(self):
        auth = Authentication("synthetic-test-password")
        self.assertNotIn("synthetic-test-password", repr(auth.__dict__))
        self.assertEqual(auth.login("wrong", "127.0.0.1"), (None, 401))
        token, status = auth.login("synthetic-test-password", "127.0.0.1")
        self.assertEqual(status, 200)
        self.assertTrue(auth.check(token))
        with patch("web_app.time.monotonic", return_value=time.monotonic() + 1801):
            self.assertFalse(auth.check(token))

    def test_rate_limit_and_logout(self):
        auth = Authentication("synthetic-test-password")
        for _ in range(5):
            self.assertEqual(auth.login("wrong", "127.0.0.1")[1], 401)
        self.assertEqual(auth.login("synthetic-test-password", "127.0.0.1")[1], 429)
        token, _ = auth.login("synthetic-test-password", "192.168.1.2")
        auth.logout(token)
        self.assertFalse(auth.check(token))

    def test_only_loopback_addresses_allowed(self):
        for address in ("127.0.0.1", "127.0.0.2"):
            self.assertTrue(private_address(address))
        for address in ("192.168.1.8", "10.1.2.3", "172.20.0.1", "8.8.8.8", "0.0.0.0", "example.com", "::1", "172.32.0.1"):
            self.assertFalse(private_address(address))

    def test_lan_binding_is_refused_before_creating_socket(self):
        with patch("socket.socket", side_effect=AssertionError("socket must not open")):
            with self.assertRaisesRegex(ValueError, "127.0.0.1"):
                LedgerServer(("0.0.0.0", 8443), Path("unused"), Authentication("synthetic-test-password"), None, {"192.168.1.8"})


@unittest.skipUnless(importlib.util.find_spec("cryptography"), "Install requirements-web.txt for HTTPS tests")
class WebHTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.temp.name)
        cls.ledger = cls.root / "ledger.json"
        cls.rows = [parse_message("현대카드 승인 12,000원 10/03 08:12 스타벅스테스트점", 2026)]
        save_ledger(str(cls.ledger), cls.rows)
        cls.context, _ = tls_context(cls.root / "tls", ["127.0.0.1"])
        cls.client_context = ssl.create_default_context(cafile=str(cls.root / "tls/certificate.pem"))
        cls.server = LedgerServer(("127.0.0.1", 0), cls.ledger, Authentication("synthetic-test-password"), cls.context, {"127.0.0.1"})
        cls.port = cls.server.server_port
        cls.origin = f"https://127.0.0.1:{cls.port}"
        cls.thread = threading.Thread(target=cls.server.serve_forever, kwargs={"poll_interval": .05}, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()
        cls.temp.cleanup()

    def setUp(self):
        self.server.auth = Authentication("synthetic-test-password")
        save_ledger(str(self.ledger), self.rows)

    def request(self, path, method="GET", body=None, headers=None):
        connection = http.client.HTTPSConnection("127.0.0.1", self.port, context=self.client_context, timeout=5)
        try:
            connection.request(method, path, body=body, headers=headers or {})
            response = connection.getresponse()
            return response.status, dict(response.getheaders()), response.read()
        finally:
            connection.close()

    def login(self):
        status, headers, _ = self.request("/login", "POST", urlencode({"password": "synthetic-test-password"}),
                                        {"Content-Type": "application/x-www-form-urlencoded", "Origin": self.origin})
        self.assertEqual(status, 200)
        self.assertIn("Secure", headers["Set-Cookie"])
        self.assertIn("HttpOnly", headers["Set-Cookie"])
        self.assertIn("SameSite=Strict", headers["Set-Cookie"])
        return headers["Set-Cookie"].split(";")[0]

    def test_login_page_contains_no_data_and_api_requires_login(self):
        status, headers, body = self.request("/")
        self.assertEqual(status, 200)
        self.assertIn(b"login-form", body)
        self.assertNotIn("스타벅스테스트점".encode(), body)
        self.assertIn("no-store", headers["Cache-Control"])
        self.assertEqual(self.request("/api/ledger")[0], 401)
        self.assertEqual(self.request("/api/ledger", headers={"Cookie": f"{COOKIE}=forged"})[0], 401)

    def test_login_and_snapshot_expose_only_explicit_ledger_fields(self):
        cookie = self.login()
        status, headers, body = self.request("/api/ledger", headers={"Cookie": cookie})
        self.assertEqual(status, 200)
        data = json.loads(body)
        self.assertEqual(data["months"][0]["total"], 12000)
        self.assertEqual(data["transactions"][0]["merchant"], "스타벅스테스트점")
        self.assertNotIn("id", data["transactions"][0])
        self.assertNotIn(str(self.root), body.decode())
        self.assertNotIn("Access-Control-Allow-Origin", headers)
        self.assertIn("frame-ancestors 'none'", headers["Content-Security-Policy"])

    def test_cross_origin_post_and_rebinding_host_are_rejected(self):
        self.assertEqual(self.request("/login", "POST", "password=anything", {"Origin": "https://evil.invalid", "Content-Type": "application/x-www-form-urlencoded"})[0], 403)
        self.assertEqual(self.request("/api/ledger", headers={"Host": f"evil.invalid:{self.port}"})[0], 403)
        self.assertEqual(self.request("/login", "POST", "password=anything", {"Content-Type": "application/x-www-form-urlencoded"})[0], 403)

    def test_file_paths_directory_listing_and_write_routes_are_unavailable(self):
        cookie = self.login()
        for path in ("/ledger.json", "/내문자.txt", "/downloads_test/", "/../ledger.py", "/%2e%2e/ledger.py", "/.web-local/private-key.pem", "/api/ledger?path=anything"):
            with self.subTest(path=path):
                # HTTP request targets are ASCII; percent-encode any Korean names.
                from urllib.parse import quote
                self.assertEqual(self.request(quote(path, safe="/%?="), headers={"Cookie": cookie})[0], 404)
        self.assertEqual(self.request("/api/ledger", "POST", "", {"Cookie": cookie, "Origin": self.origin})[0], 404)

    def test_logout_revokes_session(self):
        cookie = self.login()
        status, headers, _ = self.request("/logout", "POST", "", {"Cookie": cookie, "Origin": self.origin, "Content-Type": "application/x-www-form-urlencoded"})
        self.assertEqual(status, 200)
        self.assertIn("Max-Age=0", headers["Set-Cookie"])
        self.assertEqual(self.request("/api/ledger", headers={"Cookie": cookie})[0], 401)

    def test_unreadable_ledger_fails_closed_without_path_or_traceback(self):
        cookie = self.login()
        self.ledger.write_text("invalid", encoding="utf-8")
        status, _, body = self.request("/api/ledger", headers={"Cookie": cookie})
        self.assertEqual(status, 503)
        self.assertEqual(json.loads(body), {"error": "ledger_unavailable"})

    def test_snapshot_refreshes_on_disk_changes_and_does_not_write_data(self):
        cookie = self.login()
        before = self.ledger.read_bytes()
        self.assertEqual(self.request("/api/ledger", headers={"Cookie": cookie})[0], 200)
        self.assertEqual(self.ledger.read_bytes(), before)
        save_ledger(str(self.ledger), [])
        status, _, body = self.request("/api/ledger", headers={"Cookie": cookie})
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body)["months"], [])

    def test_oversized_login_request_is_rejected(self):
        self.assertEqual(self.request("/login", "POST", "x" * 4097, {"Origin": self.origin, "Content-Type": "application/x-www-form-urlencoded"})[0], 400)

    def test_certificate_reuse_keeps_private_key_local(self):
        key = self.root / "tls/private-key.pem"
        before = key.read_bytes()
        _, fingerprint = tls_context(self.root / "tls", ["127.0.0.1"])
        self.assertTrue(fingerprint)
        self.assertEqual(key.read_bytes(), before)


if __name__ == "__main__":
    unittest.main()
