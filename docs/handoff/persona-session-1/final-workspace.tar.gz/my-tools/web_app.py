"""Read-only HTTPS dashboard restricted to this computer's loopback interface.

No cloud hosting, file browser, uploads, analytics, or outbound requests.
"""
from __future__ import annotations

import argparse
import getpass
import hashlib
import hmac
import ipaddress
import json
import secrets
import ssl
import threading
import time
import warnings
from datetime import datetime, timedelta, timezone
from http.cookies import SimpleCookie, CookieError
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from socketserver import TCPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from local_io import atomic_write
from ledger import ledger_revision, load_ledger, summarize

BASE = Path(__file__).resolve().parent
STATIC = BASE / "web"
COOKIE = "__Host-ledger_session"


def private_address(value: str) -> bool:
    try:
        address = ipaddress.ip_address(value)
        return address.version == 4 and address.is_loopback
    except ValueError:
        return False


def tls_context(directory: Path, addresses: list[str]) -> tuple[ssl.SSLContext, str]:
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID

    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    certificate, private_key = directory / "certificate.pem", directory / "private-key.pem"
    names = {"localhost", *addresses}
    reusable = False
    if certificate.is_file() and private_key.is_file():
        try:
            cert = x509.load_pem_x509_certificate(certificate.read_bytes())
            sans = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
            present = set(sans.get_values_for_type(x509.DNSName)) | {str(ip) for ip in sans.get_values_for_type(x509.IPAddress)}
            reusable = names <= present and cert.not_valid_after_utc > datetime.now(timezone.utc) + timedelta(days=1)
        except (ValueError, x509.ExtensionNotFound):
            pass
    if not reusable:
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Local Ledger")])
        now = datetime.now(timezone.utc)
        cert = (x509.CertificateBuilder().subject_name(subject).issuer_name(subject).public_key(key.public_key())
                .serial_number(x509.random_serial_number()).not_valid_before(now - timedelta(minutes=5))
                .not_valid_after(now + timedelta(days=30))
                .add_extension(x509.SubjectAlternativeName([x509.DNSName("localhost")] + [x509.IPAddress(ipaddress.ip_address(ip)) for ip in addresses]), critical=False)
                .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
                .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
                .sign(key, hashes.SHA256()))
        atomic_write(str(private_key), key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
        atomic_write(str(certificate), cert.public_bytes(serialization.Encoding.PEM))
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(str(certificate), str(private_key))
    return context, cert.fingerprint(hashes.SHA256()).hex(":")


class Authentication:
    def __init__(self, password: str):
        if len(password) < 10 or not password.strip():
            raise ValueError("접속 비밀번호는 10자 이상으로 설정해 주세요.")
        self.salt = secrets.token_bytes(16)
        self.password_hash = self._hash(password)
        self.sessions: dict[str, float] = {}
        self.failures: dict[str, list[float]] = {}
        self.lock = threading.Lock()

    def _hash(self, password):
        return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), self.salt, 300_000)

    def login(self, password: str, address: str) -> tuple[str | None, int]:
        with self.lock:
            now = time.monotonic()
            self.failures = {ip: [t for t in attempts if now - t < 60] for ip, attempts in self.failures.items() if any(now - t < 60 for t in attempts)}
            attempts = self.failures.setdefault(address, [])
            if len(attempts) >= 5:
                return None, 429
            if not hmac.compare_digest(self.password_hash, self._hash(password)):
                attempts.append(now)
                return None, 401
            self.failures.pop(address, None)
            self.sessions = {key: stamp for key, stamp in self.sessions.items() if now - stamp < 1800}
            if len(self.sessions) >= 100:
                self.sessions.pop(min(self.sessions, key=self.sessions.get))
            token = secrets.token_urlsafe(32)
            self.sessions[token] = now
            return token, 200

    def check(self, token: str) -> bool:
        with self.lock:
            now = time.monotonic()
            stamp = self.sessions.get(token)
            if stamp is None or now - stamp >= 1800:
                self.sessions.pop(token, None)
                return False
            self.sessions[token] = now
            return True

    def logout(self, token: str):
        with self.lock:
            self.sessions.pop(token, None)


def snapshot(path: Path) -> dict:
    rows = load_ledger(str(path))
    # Explicit fields only: no original SMS, file paths, or other local files.
    transactions = [{key: getattr(row, key) for key in (
        "date", "card", "merchant", "amount", "category", "cancelled", "excluded", "exclusion_reason",
        "category_method", "original_currency", "original_amount", "fx_rate", "fx_date", "fx_estimated", "review_note")}
        for row in sorted(rows, key=lambda row: row.date, reverse=True)]
    months = sorted({row.date[:7] for row in rows}, reverse=True)
    return {"months": [summarize(rows, month) for month in months], "transactions": transactions,
            "updated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"), "revision": ledger_revision(rows),
            "schema_version": 2}


class LedgerServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 16

    def __init__(self, address, ledger: Path, auth: Authentication, context: ssl.SSLContext, allowed_hosts: set[str]):
        if address[0] != "127.0.0.1":
            raise ValueError("오프라인 보호 모드에서는 127.0.0.1에만 실행할 수 있습니다.")
        self.ledger, self.auth, self.context = ledger, auth, context
        self.allowed_hosts = {"localhost", "127.0.0.1"}
        super().__init__(address, LedgerHandler)

    def server_bind(self):
        # Avoid HTTPServer's reverse hostname lookup; no DNS is needed here.
        TCPServer.server_bind(self)
        self.server_name = "localhost"
        self.server_port = self.server_address[1]

    def get_request(self):
        connection, address = super().get_request()
        if not private_address(address[0]):
            connection.close()
            raise OSError("Loopback clients only")
        connection.settimeout(10)
        try:
            return self.context.wrap_socket(connection, server_side=True), address
        except (ssl.SSLError, OSError):
            connection.close()
            raise

    def handle_error(self, request, client_address):
        # No request/password/transaction logs or error tracebacks.
        pass


class LedgerHandler(BaseHTTPRequestHandler):
    server_version = "LocalLedger"
    sys_version = ""

    def log_message(self, *args):
        pass

    def response(self, status, body=b"", content_type="text/plain; charset=utf-8", headers=()):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store, private, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        for name, value in headers:
            self.send_header(name, value)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def valid_host(self):
        try:
            if len(self.headers.get_all("Host", [])) != 1:
                return False
            authority = urlsplit("https://" + self.headers["Host"])
            return (authority.hostname in self.server.allowed_hosts
                    and (authority.port or 443) == self.server.server_port
                    and not authority.username and not authority.password and not authority.path
                    and not authority.query and not authority.fragment)
        except ValueError:
            return False

    def token(self):
        try:
            cookies = SimpleCookie()
            cookies.load(self.headers.get("Cookie", ""))
            return cookies[COOKIE].value if COOKIE in cookies else ""
        except CookieError:
            return ""

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        if not self.valid_host():
            self.response(403, b"Host not allowed")
            return
        if self.path in ("/app.css", "/app.js", "/login.js"):
            kind = "text/css" if self.path.endswith(".css") else "text/javascript"
            self.response(200, (STATIC / self.path[1:]).read_bytes(), kind + "; charset=utf-8")
        elif self.path in ("/", "/login"):
            page = "index.html" if self.server.auth.check(self.token()) else "login.html"
            self.response(200, (STATIC / page).read_bytes(), "text/html; charset=utf-8")
        elif self.path == "/api/ledger":
            if not self.server.auth.check(self.token()):
                self.response(401, b'{"error":"login_required"}', "application/json")
                return
            try:
                body = json.dumps(snapshot(self.server.ledger), ensure_ascii=False).encode("utf-8")
            except (OSError, ValueError, TypeError, KeyError):
                self.response(503, b'{"error":"ledger_unavailable"}', "application/json")
                return
            self.response(200, body, "application/json; charset=utf-8")
        else:
            self.response(404, b"Not found")

    def do_POST(self):
        if not self.valid_host() or self.headers.get("Origin") != "https://" + self.headers.get("Host", ""):
            self.response(403, b"Origin not allowed")
            return
        if self.path not in ("/login", "/logout"):
            self.response(404, b"Not found")
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 0 or length > 4096 or self.headers.get("Transfer-Encoding"):
                raise ValueError
            if self.headers.get("Content-Type", "").split(";")[0] != "application/x-www-form-urlencoded":
                raise ValueError
            fields = parse_qs(self.rfile.read(length).decode("utf-8"), max_num_fields=2)
        except (ValueError, UnicodeError):
            self.response(400, b"Invalid form")
            return
        if self.path == "/logout":
            self.server.auth.logout(self.token())
            self.response(200, b"{}", "application/json", [("Set-Cookie", f"{COOKIE}=; Path=/; Max-Age=0; Secure; HttpOnly; SameSite=Strict")])
            return
        passwords = fields.get("password", [])
        if len(passwords) != 1:
            self.response(400, b"Invalid form")
            return
        token, status = self.server.auth.login(passwords[0], self.client_address[0])
        if token:
            self.response(200, b"{}", "application/json", [("Set-Cookie", f"{COOKIE}={token}; Path=/; Secure; HttpOnly; SameSite=Strict")])
        else:
            self.response(status, b'{"error":"login_failed"}', "application/json", [("Retry-After", "60")] if status == 429 else [])


def main():
    parser = argparse.ArgumentParser(description="이 컴퓨터에서만 보는 로컬 HTTPS 가계부 (외부 기기 접속 차단)")
    parser.add_argument("--ledger", type=Path, default=BASE / "카드내역.json")
    parser.add_argument("--port", type=int, default=8443)
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("유효한 포트를 지정해 주세요.")
    try:
        snapshot(args.ledger)
        addresses = ["127.0.0.1"]
        with warnings.catch_warnings():
            warnings.simplefilter("error", getpass.GetPassWarning)
            password = getpass.getpass("웹 접속 비밀번호 (10자 이상): ")
            confirmation = getpass.getpass("같은 비밀번호 다시 입력: ")
        if password != confirmation:
            raise ValueError("입력한 비밀번호가 서로 다릅니다.")
        auth = Authentication(password)
        del password, confirmation
        context, fingerprint = tls_context(BASE / ".web-local", addresses)
        server = LedgerServer(("127.0.0.1", args.port), args.ledger.resolve(), auth, context, set(addresses))
    except (OSError, ValueError, TypeError, KeyError, ImportError) as exc:
        parser.exit(1, f"시작하지 못했습니다: {exc}\n설치 안내: README.md의 ‘컴퓨터에서만 보는 웹 가계부’를 확인하세요.\n")
    except (EOFError, KeyboardInterrupt, getpass.GetPassWarning):
        parser.exit(1, "\n비밀번호를 숨길 수 있는 터미널에서 다시 실행해 주세요.\n")
    print("가계부 보기 전용 웹 화면을 시작했습니다. 종료: Ctrl+C")
    print(f"컴퓨터: https://localhost:{args.port}")
    print("같은 와이파이의 폰을 포함해 외부 기기 접속은 차단됩니다.")
    print("직접 만든 인증서라 첫 접속에 경고가 표시됩니다. 본인 컴퓨터 주소인지 확인하세요.")
    print(f"인증서 SHA-256: {fingerprint}")
    try:
        server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
