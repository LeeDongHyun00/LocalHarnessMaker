import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from local_io import atomic_write


class LocalWriteTests(unittest.TestCase):
    def test_exclusive_write_preserves_existing_file_and_cleans_temporary(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "existing.bin"
            path.write_bytes(b"original")
            with self.assertRaises(FileExistsError):
                atomic_write(str(path), b"replacement", overwrite=False)
            self.assertEqual(path.read_bytes(), b"original")
            self.assertEqual(list(Path(directory).iterdir()), [path])

    def test_failed_replacement_preserves_existing_file_and_cleans_temporary(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "existing.bin"
            path.write_bytes(b"original")
            with patch("local_io.os.replace", side_effect=OSError("disk error")):
                with self.assertRaises(OSError):
                    atomic_write(str(path), b"replacement")
            self.assertEqual(path.read_bytes(), b"original")
            self.assertEqual(list(Path(directory).iterdir()), [path])


if __name__ == "__main__":
    unittest.main()
