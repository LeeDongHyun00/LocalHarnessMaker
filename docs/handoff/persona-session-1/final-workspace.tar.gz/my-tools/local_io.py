"""Atomic local writes shared by exports, public rate cache and HTTPS setup."""
from pathlib import Path
import os
import tempfile


def atomic_write(path: str, contents: bytes, *, overwrite: bool = True) -> None:
    destination = Path(path).absolute()
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=destination.parent, prefix=".local-write-", suffix=".tmp", delete=False) as file:
            temporary = Path(file.name)
            file.write(contents)
            file.flush()
            os.fsync(file.fileno())
        if overwrite:
            os.replace(temporary, destination)
        else:
            os.link(temporary, destination)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
