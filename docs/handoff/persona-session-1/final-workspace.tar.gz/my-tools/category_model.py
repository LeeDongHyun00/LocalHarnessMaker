"""Small offline text classifier: character n-gram TF-IDF nearest neighbours.

No downloads, remote models, telemetry, or third-party dependencies.
Scores describe text similarity, not calibrated probabilities of correctness.
"""
from __future__ import annotations

import math
import re
import unicodedata
from collections import Counter, defaultdict
from dataclasses import dataclass

SEEDS = {
    "식비·배달": ("본죽", "한솥도시락", "맥도날드", "써브웨이", "서브웨이", "맘스터치", "도미노피자", "샐러디"),
    "카페·간식": ("파리바게뜨", "뚜레쥬르", "던킨", "배스킨라빈스", "빽다방", "폴바셋", "블루보틀"),
    "식료품·생활": ("CU편의점", "미니스톱", "코스트코", "노브랜드", "트레이더스", "올리브영"),
    "교통·차량": ("티머니", "티맵모빌리티", "쏘카", "그린카", "우티", "고속버스"),
    "의료·건강": ("건강검진센터", "보건소"),
    "문화·구독": ("왓챠", "웨이브", "티빙", "디즈니플러스", "밀리의서재", "리디북스", "알라딘", "예스24"),
    "여행·숙박": ("아고다", "부킹닷컴", "트립닷컴", "제주항공", "진에어", "펜션", "리조트"),
    "쇼핑": ("에이블리", "지그재그", "오늘의집", "이케아", "유니클로"),
}


def normalize(value: str) -> str:
    return re.sub(r"[\W_]", "", unicodedata.normalize("NFKC", value).casefold())


def features(value: str) -> set[str]:
    value = normalize(value)
    return {value[i:i + n] for n in (2, 3) for i in range(len(value) - n + 1)}


@dataclass(frozen=True)
class Prediction:
    category: str
    score: float
    method: str

    @property
    def needs_review(self) -> bool:
        return self.method == "확인 필요"


class LocalCategorizer:
    def __init__(self, rules, confirmed=()):
        self.rules = rules
        labels = {category for category, _ in rules} | {"기타"}
        self.confirmed = defaultdict(set)
        for merchant, category in confirmed:
            if category not in labels:
                raise ValueError("지원하지 않는 학습 카테고리입니다.")
            name = normalize(merchant)
            if name:
                self.confirmed[name].add(category)
        seed_rows = [(name, category) for category, words in rules for name in words]
        seed_rows += [(name, category) for category, names in SEEDS.items() for name in names]
        # Repeated payments do not give a merchant extra voting weight.
        personal_rows = [(name, next(iter(values))) for name, values in self.confirmed.items() if len(values) == 1]
        documents = [features(name) for name, _ in seed_rows + personal_rows]
        frequency = Counter(token for document in documents for token in document)
        self.unseen_idf = math.log(1 + len(documents)) + 1
        self.idf = {token: math.log((1 + len(documents)) / (1 + count)) + 1 for token, count in frequency.items()}
        self.seeds = [(self.vector(name), category) for name, category in seed_rows]
        self.personal = [(self.vector(name), category) for name, category in personal_rows]

    def vector(self, name):
        weighted = {token: self.idf.get(token, self.unseen_idf) for token in features(name)}
        length = math.sqrt(sum(value * value for value in weighted.values())) or 1
        return {token: value / length for token, value in weighted.items()}

    @staticmethod
    def nearest(vector, examples):
        scores = defaultdict(float)
        for candidate, category in examples:
            similarity = sum(value * candidate.get(token, 0) for token, value in vector.items())
            scores[category] = max(scores[category], similarity)
        ranking = sorted(scores.items(), key=lambda pair: (-pair[1], pair[0]))
        if not ranking:
            return "기타", 0.0, 0.0
        category, score = ranking[0]
        margin = score - (ranking[1][1] if len(ranking) > 1 else 0)
        return category, min(1.0, score), margin

    @staticmethod
    def ambiguous(name):
        # Payment gateways / general stores cannot reveal the purchased item.
        return (any(token in name for token in ("네이버페이", "카카오페이", "토스페이", "페이코", "paypal", "스마트스토어"))
                or ("쿠팡" in name and "쿠팡이츠" not in name))

    def predict(self, merchant: str) -> Prediction:
        name = normalize(merchant)
        labels = self.confirmed.get(name, set())
        if len(labels) == 1:
            return Prediction(next(iter(labels)), 1.0, "사용자 학습")
        keyword = next((category for category, words in self.rules if any(normalize(word) in name for word in words)), "기타")
        if len(labels) > 1:
            return Prediction(keyword, 0.0, "확인 필요")
        # An ambiguous marketplace remains reviewable unless this exact name was confirmed.
        if self.ambiguous(name):
            return Prediction(keyword, 0.0, "확인 필요")
        vector = self.vector(name)
        personal, score, margin = self.nearest(vector, self.personal)
        if score >= 0.65 and margin >= 0.12:
            return Prediction(personal, round(score, 4), "사용자 학습")
        if keyword != "기타":
            return Prediction(keyword, 1.0, "키워드")
        if score >= 0.45 and margin >= 0.12:
            return Prediction(personal, round(score, 4), "확인 필요")
        category, score, margin = self.nearest(vector, self.seeds)
        if score < 0.35 or margin < 0.08:
            return Prediction("기타", round(score, 4), "확인 필요")
        return Prediction(category, round(score, 4), "로컬 모델" if score >= 0.65 else "확인 필요")
