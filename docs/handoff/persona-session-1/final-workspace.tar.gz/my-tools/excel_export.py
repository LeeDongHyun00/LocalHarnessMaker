"""Write a local .xlsx workbook without extra packages or password prompts."""
from __future__ import annotations

import io
import re
from xml.etree.ElementTree import Element, SubElement, tostring
from zipfile import ZIP_DEFLATED, ZipFile

from ledger import Transaction, ledger_revision, summarize
from local_io import atomic_write

SHEET_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
DOC_REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PACKAGE_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
CONTENT_NS = "http://schemas.openxmlformats.org/package/2006/content-types"


def _xml(element: Element) -> bytes:
    return tostring(element, encoding="utf-8", xml_declaration=True)


def _sheet(month: str, rows: list[Transaction], review_count: int, revision: str) -> bytes:
    root = Element("worksheet", xmlns=SHEET_NS)
    views = SubElement(root, "sheetViews")
    view = SubElement(views, "sheetView", workbookViewId="0")
    SubElement(view, "pane", ySplit="18", topLeftCell="A19", activePane="bottomLeft", state="frozen")
    cols = SubElement(root, "cols")
    for i, width in enumerate((22, 20, 38, 18, 20, 12, 22, 16, 65, 18, 10, 22, 22, 18, 18, 65, 65), 1):
        SubElement(cols, "col", min=str(i), max=str(i), width=str(width), customWidth="1")
    data = SubElement(root, "sheetData")

    def add_row(number, values, header=False, title=False):
        row = SubElement(data, "row", r=str(number))
        for i, value in enumerate(values):
            style = "3" if type(value) is int else "1" if header else "2" if title else "0"
            cell = SubElement(row, "c", r=f"{chr(65 + i)}{number}", s=style)
            if type(value) is int:
                SubElement(cell, "v").text = str(value)
            else:
                # inlineStr keeps all text literal, including text starting with '='.
                cell.set("t", "inlineStr")
                text = SubElement(SubElement(cell, "is"), "t", {"{http://www.w3.org/XML/1998/namespace}space": "preserve"})
                text.text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff\ufffe\uffff]", "", str(value))

    summary = summarize(rows, month)
    add_row(1, [f"{month} 카드 지출"], title=True)
    note = "단위: 원 · 내보낸 시점의 집계 · 취소는 해당 문자 날짜 기준 · 할부는 승인 총액"
    if review_count:
        note += f" · 해석하지 못한 문자 {review_count}건은 전체 내보내기에서 제외"
    add_row(2, [note])
    add_row(3, ["전체 승인", summary["recorded_approved"], "", "집계 제외 건수", summary["excluded_count"]])
    add_row(4, ["전체 취소", summary["recorded_cancelled"], "", "집계 제외 순금액", summary["excluded_amount"]])
    add_row(5, ["집계 순지출", summary["total"], "", "분류 확인 필요", summary["category_review_count"]])
    add_row(6, [f"전체 승인 − 전체 취소 − 제외 순금액 = 집계 순지출 · 환산 추정 {summary['fx_estimated_count']}건 · 수수료 미포함"])
    add_row(7, ["카테고리", "금액(원)"], header=True)
    for number, (category, amount) in enumerate(summary["categories"].items(), 8):
        add_row(number, [category, amount])
    add_row(17, ["내역 버전", revision, "", "내역 확인 메모 건수", summary["pending_review_count"]])
    add_row(18, ["일시", "카드", "가맹점", "금액(원)", "카테고리", "구분", "집계 반영액(원)", "집계 상태", "제외 사유", "분류 상태",
                 "원통화", "원거래금액(절댓값)", "적용환율(원/USD)", "환율 기준일", "금액 상태", "환율 출처", "확인 메모"], header=True)
    for number, row in enumerate(sorted(rows, key=lambda row: row.date), 19):
        add_row(number, [row.date.replace("T", " "), row.card, row.merchant, row.amount,
                         row.category, "취소" if row.cancelled else "승인", 0 if row.excluded else row.amount,
                         "제외" if row.excluded else "포함", row.exclusion_reason, row.category_method,
                         row.original_currency, row.original_amount if row.original_currency == "USD" else abs(row.amount),
                         row.fx_rate, row.fx_date, "환율 추정" if row.fx_estimated else "직접 입력" if row.original_currency == "USD" else "원화 승인", row.fx_source, row.review_note])
    SubElement(root, "autoFilter", ref=f"A18:Q{18 + len(rows)}")
    return _xml(root)


def _styles() -> bytes:
    root = Element("styleSheet", xmlns=SHEET_NS)
    formats = SubElement(root, "numFmts", count="1")
    SubElement(formats, "numFmt", numFmtId="164", formatCode="#,##0;[Red]-#,##0")
    fonts = SubElement(root, "fonts", count="3")
    for bold, color, size in ((False, "FF222222", "11"), (True, "FFFFFFFF", "11"), (True, "FF222222", "16")):
        font = SubElement(fonts, "font")
        SubElement(font, "sz", val=size)
        SubElement(font, "name", val="맑은 고딕")
        SubElement(font, "color", rgb=color)
        if bold:
            SubElement(font, "b")
    fills = SubElement(root, "fills", count="3")
    for pattern in ("none", "gray125", "solid"):
        fill = SubElement(fills, "fill")
        pattern_fill = SubElement(fill, "patternFill", patternType=pattern)
        if pattern == "solid":
            SubElement(pattern_fill, "fgColor", rgb="FF243B53")
            SubElement(pattern_fill, "bgColor", indexed="64")
    borders = SubElement(root, "borders", count="1")
    SubElement(borders, "border")
    base = SubElement(root, "cellStyleXfs", count="1")
    SubElement(base, "xf", numFmtId="0", fontId="0", fillId="0", borderId="0")
    styles = SubElement(root, "cellXfs", count="4")
    for font, fill, number in ((0, 0, 0), (1, 2, 0), (2, 0, 0), (0, 0, 164)):
        SubElement(styles, "xf", numFmtId=str(number), fontId=str(font), fillId=str(fill), borderId="0", xfId="0")
    names = SubElement(root, "cellStyles", count="1")
    SubElement(names, "cellStyle", name="Normal", xfId="0", builtinId="0")
    return _xml(root)


def export_xlsx(path: str, rows: list[Transaction], *, review_count: int = 0) -> None:
    """Export all months, in order, to one workbook. Original SMS are not included."""
    if not rows:
        raise ValueError("내보낼 내역이 없습니다. 먼저 문자를 분석하거나 파일을 열어 주세요.")
    months = sorted({row.date[:7] for row in rows})
    workbook = Element("workbook", xmlns=SHEET_NS, attrib={"xmlns:r": DOC_REL_NS})
    sheets = SubElement(workbook, "sheets")
    relationships = Element("Relationships", xmlns=PACKAGE_REL_NS)
    content = Element("Types", xmlns=CONTENT_NS)
    SubElement(content, "Default", Extension="rels", ContentType="application/vnd.openxmlformats-package.relationships+xml")
    SubElement(content, "Default", Extension="xml", ContentType="application/xml")
    for part, kind in (("workbook", "sheet.main"), ("styles", "styles")):
        SubElement(content, "Override", PartName=f"/xl/{part}.xml",
                   ContentType=f"application/vnd.openxmlformats-officedocument.spreadsheetml.{kind}+xml")
    for i, month in enumerate(months, 1):
        SubElement(sheets, "sheet", name=month, sheetId=str(i), attrib={"r:id": f"rId{i}"})
        SubElement(relationships, "Relationship", Id=f"rId{i}", Type=f"{DOC_REL_NS}/worksheet", Target=f"worksheets/sheet{i}.xml")
        SubElement(content, "Override", PartName=f"/xl/worksheets/sheet{i}.xml",
                   ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml")
    SubElement(relationships, "Relationship", Id="styles", Type=f"{DOC_REL_NS}/styles", Target="styles.xml")
    package = Element("Relationships", xmlns=PACKAGE_REL_NS)
    SubElement(package, "Relationship", Id="rId1", Type=f"{DOC_REL_NS}/officeDocument", Target="xl/workbook.xml")
    with io.BytesIO() as plain:
        with ZipFile(plain, "w", compression=ZIP_DEFLATED) as archive:
            archive.writestr("[Content_Types].xml", _xml(content))
            archive.writestr("_rels/.rels", _xml(package))
            archive.writestr("xl/workbook.xml", _xml(workbook))
            archive.writestr("xl/_rels/workbook.xml.rels", _xml(relationships))
            archive.writestr("xl/styles.xml", _styles())
            for i, month in enumerate(months, 1):
                monthly_rows = [row for row in rows if row.date.startswith(month + "-")]
                archive.writestr(f"xl/worksheets/sheet{i}.xml", _sheet(month, monthly_rows, review_count, ledger_revision(rows)))
        contents = plain.getvalue()
    atomic_write(path, contents)
