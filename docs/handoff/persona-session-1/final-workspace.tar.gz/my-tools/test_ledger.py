import csv
import json
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

from ledger import (categorize, export_csv, load_ledger, parse_message,
                    parse_messages, save_ledger, summarize)

EXAMPLE = Path(__file__).with_name("example_sms.txt").read_text(encoding="utf-8")


class LedgerTests(unittest.TestCase):
    def test_user_examples_ignore_cumulative_amount(self):
        rows, rejected = parse_messages(EXAMPLE, 2026)
        self.assertEqual(rejected, [])
        result = summarize(rows, "2026-10")
        self.assertEqual(result["count"], 3)
        self.assertEqual(result["total"], 90800)
        self.assertEqual(result["categories"]["카페·간식"], 12000)
        self.assertEqual(result["categories"]["쇼핑"], 45800)
        self.assertEqual(result["categories"]["식비·배달"], 33000)

    def test_without_web_markers_and_windows_newlines(self):
        text = EXAMPLE.replace("[Web발신]", "").replace("\n", "\r\n")
        rows, rejected = parse_messages(text, 2026)
        self.assertEqual((len(rows), len(rejected)), (3, 0))

    def test_cancellation_is_negative_in_its_own_month(self):
        rows, _ = parse_messages(EXAMPLE, 2026)
        cancellation = parse_message("신한카드 승인취소 12,000원 11/01 09:00 스타벅스강남R점 누적1,000원", 2026)
        rows.append(cancellation)
        self.assertEqual(summarize(rows, "2026-10")["total"], 90800)
        november = summarize(rows, "2026-11")
        self.assertEqual((november["approved"], november["cancelled"], november["total"]), (0, 12000, -12000))

    def test_explicit_year_overrides_selected_year(self):
        row = parse_message("현대카드 승인 1,000원 2025-12-31 23:59 동네가게", 2026)
        self.assertEqual(row.date, "2025-12-31T23:59")
        self.assertEqual(row.category, "기타")

    def test_fingerprint_accounts_for_year_but_ignores_whitespace(self):
        text = "신한카드 승인 12,000원 10/03 08:12 스타벅스"
        a = parse_message(text, 2026)
        b = parse_message(text.replace(" ", "\n"), 2026)
        self.assertEqual(a.id, b.id)
        self.assertNotEqual(a.id, parse_message(text, 2025).id)

    def test_failed_messages_are_reported_without_losing_valid_ones(self):
        rows, rejected = parse_messages(EXAMPLE + "\n[Web발신]\n현대카드 승인 USD 10.00 10/02 13:00 해외가게", 2026)
        self.assertEqual(len(rows), 3)
        self.assertEqual(len(rejected), 1)
        self.assertIn("USD", rejected[0].text)

    def test_invalid_or_ambiguous_messages_rejected(self):
        for text in (
            "현대카드 승인 1,000원 02/30 12:00 가게",
            "현대카드 승인 1,000원 10/01 25:00 가게",
            "현대카드 승인거절 1,000원 10/01 12:00 가게",
            "현대카드 취소실패 1,000원 10/01 12:00 가게",
            "현대카드 승인 1,000원 할인 100원 10/01 12:00 가게",
            "현대카드 승인 0원 10/01 12:00 가게",
            "현대카드 승인 1,000원 10/01 12:00 누적5,000원",
            "인증번호 123456",
        ):
            with self.subTest(text=text), self.assertRaises(ValueError):
                parse_message(text, 2026)

    def test_specific_rules_precede_generic_marketplace(self):
        self.assertEqual(categorize("쿠팡이츠"), "식비·배달")
        self.assertEqual(categorize("쿠팡"), "쇼핑")

    def test_explicit_exclusion_preserves_approval_and_only_omits_selected_row(self):
        purchase = parse_message("현대카드 승인 70,000원 10/15 12:00 테스트주유소", 2026)
        other = parse_message("현대카드 승인 70,000원 10/16 12:00 테스트주유소", 2026)
        self.assertFalse(purchase.excluded)
        self.assertEqual(summarize([purchase, other], "2026-10")["total"], 140000)
        pending = replace(purchase, excluded=True, exclusion_reason="확인 대기")
        result = summarize([pending, other], "2026-10")
        self.assertEqual((result["total"], result["count"], result["excluded_count"], result["excluded_amount"]),
                         (70000, 1, 1, 70000))
        self.assertEqual(result["categories"]["교통·차량"], 70000)
        self.assertEqual((pending.amount, pending.cancelled), (70000, False))
        self.assertEqual(summarize([replace(pending, excluded=False), other], "2026-10")["total"], 140000)

    def test_excluded_refund_does_not_reduce_total(self):
        rows, _ = parse_messages(EXAMPLE, 2026)
        refund = replace(rows[0], amount=-12000, cancelled=True, excluded=True, exclusion_reason="확인 대기")
        result = summarize([refund], "2026-10")
        self.assertEqual((result["total"], result["cancelled"], result["excluded_amount"]), (0, 0, -12000))

    def test_exclusions_roundtrip_and_older_files_still_load(self):
        rows, _ = parse_messages(EXAMPLE, 2026)
        rows[0] = replace(rows[0], excluded=True, exclusion_reason="확인 대기")
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "ledger.json")
            save_ledger(path, rows)
            self.assertEqual(load_ledger(path), rows)
            data = json.loads(Path(path).read_text(encoding="utf-8"))
            for item in data["transactions"]:
                del item["excluded"]
                del item["exclusion_reason"]
            Path(path).write_text(json.dumps(data), encoding="utf-8")
            self.assertTrue(all(not row.excluded for row in load_ledger(path)))

    def test_csv_exclusion_is_visible_with_original_and_counted_amounts(self):
        rows, _ = parse_messages(EXAMPLE, 2026)
        row = replace(rows[0], excluded=True, exclusion_reason="확인 대기")
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "ledger.csv")
            export_csv(path, [row])
            with open(path, encoding="utf-8-sig", newline="") as file:
                content = list(csv.reader(file))
            self.assertEqual(content[1][3:9], ["12000", "카페·간식", "승인", "0", "제외", "확인 대기"])

    def test_woori_check_sms_counts_purchase_not_balance_and_omits_card_digits(self):
        text = "우리(9876)체크승인 김*수 5,100원 10/12 09:15 GS25테스트점 잔액999,999원"
        row = parse_message(text, 2026)
        self.assertEqual((row.card, row.merchant, row.amount, row.category, row.cancelled),
                         ("우리체크카드", "GS25테스트점", 5100, "식료품·생활", False))
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "ledger.json")
            save_ledger(path, [row])
            restored = load_ledger(path)[0]
            self.assertEqual(restored, row)
            self.assertNotIn("9876", restored.card)
            self.assertNotIn("김*수", Path(path).read_text(encoding="utf-8"))

    def test_woori_check_variants_and_cancellation(self):
        for header in ("우리(9*7*)체크", "우리체크", "우리 체크카드", "우리카드 체크"):
            with self.subTest(header=header):
                row = parse_message(f"{header}승인취소 5,100원 10/13 10:00 GS25테스트점", 2026)
                self.assertEqual(row.amount, -5100)
                self.assertTrue(row.cancelled)
                self.assertEqual(row.category, "식료품·생활")

    def test_woori_check_is_split_from_previous_sms_without_web_marker(self):
        text = EXAMPLE.replace("[Web발신]", "") + "\n우리(9876)체크승인 5,100원 10/12 09:15 GS25테스트점 잔액999,999원"
        rows, rejected = parse_messages(text, 2026)
        self.assertEqual((len(rows), len(rejected)), (4, 0))
        result = summarize(rows, "2026-10")
        self.assertEqual(result["total"], 95900)
        self.assertEqual(result["categories"]["식료품·생활"], 5100)

    def test_local_save_roundtrip_omits_sms_and_personal_identifiers(self):
        rows, _ = parse_messages(EXAMPLE, 2026)
        rows[0].category = "기타"
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "ledger.json")
            save_ledger(path, rows)
            self.assertEqual(load_ledger(path), rows)
            content = Path(path).read_text(encoding="utf-8")
            self.assertNotIn("홍*동", content)
            self.assertNotIn("1234", content)
            self.assertNotIn("Web발신", content)

    def test_invalid_saved_amount_or_category_rejected(self):
        rows, _ = parse_messages(EXAMPLE, 2026)
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "ledger.json")
            for row in (replace(rows[0], amount="12000"), replace(rows[0], category="unknown"),
                        replace(rows[0], cancelled=True)):
                save_ledger(path, [row])
                with self.assertRaises(ValueError):
                    load_ledger(path)

    def test_failed_save_preserves_previous_file_and_cleans_temporary_file(self):
        rows, _ = parse_messages(EXAMPLE, 2026)
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "ledger.json")
            save_ledger(path, rows)
            previous = Path(path).read_bytes()
            with patch("ledger.os.replace", side_effect=OSError("disk error")):
                with self.assertRaises(OSError):
                    save_ledger(path, [])
            self.assertEqual(Path(path).read_bytes(), previous)
            self.assertEqual(list(Path(directory).iterdir()), [Path(path)])

    def test_csv_preserves_negative_amount_but_escapes_formula_text(self):
        rows, _ = parse_messages(EXAMPLE, 2026)
        row = replace(rows[0], merchant="=1+1", amount=-12000, cancelled=True)
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "export.csv")
            export_csv(path, [row])
            with open(path, encoding="utf-8-sig", newline="") as file:
                contents = list(csv.reader(file))
            self.assertEqual(contents[1][2], "'=1+1")
            self.assertEqual(contents[1][3], "-12000")


if __name__ == "__main__":
    unittest.main()
