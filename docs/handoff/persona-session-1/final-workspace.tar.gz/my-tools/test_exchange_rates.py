import json
import tempfile
import unittest
from dataclasses import replace
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path
from unittest.mock import patch
from zipfile import ZipFile

from exchange_rates import URL, RateBook, convert_usd, import_rates, load_rates, parse_ecb, usd_amount
from ledger import (export_csv, load_ledger, parse_message, parse_messages,
                    reclassify_transactions, save_ledger, summarize)
from excel_export import export_xlsx

XML = b'''<Envelope xmlns="http://www.gesmes.org/xml/2002-08-01"><Cube>
<Cube time="2025-10-03"><Cube currency="USD" rate="1.25"/><Cube currency="KRW" rate="1650"/></Cube>
<Cube time="2025-10-06"><Cube currency="USD" rate="1.2"/><Cube currency="KRW" rate="1680"/></Cube>
</Cube></Envelope>'''


class ExchangeRateTests(unittest.TestCase):
    def setUp(self):
        self.book = RateBook({"2025-10-03": "1320.25", "2025-10-06": "1400.000000"}, date.today().isoformat())
        self.sms = "현대카드 해외승인 USD 15.99 일시불 2025/10/05 09:00 NETFLIX"

    def test_ecb_euro_cross_rate_is_divided_correctly(self):
        self.assertEqual(parse_ecb(XML).rates["2025-10-03"], "1320.000000")
        self.assertEqual(parse_ecb(XML).rates["2025-10-06"], "1400.000000")

    def test_weekend_uses_preceding_published_day_and_rounds_half_up(self):
        self.assertEqual(convert_usd(Decimal("15.99"), "2025-10-05", self.book), (21111, "1320.25", "2025-10-03"))
        self.assertEqual(convert_usd(Decimal("1"), "2025-10-03", RateBook({"2025-10-03": "1320.5"}, "2025-10-03"))[0], 1321)

    def test_missing_stale_and_future_rates_are_rejected(self):
        for day in ("1998-01-01", "2025-10-20", (date.today() + timedelta(days=1)).isoformat()):
            with self.subTest(day=day), self.assertRaises(ValueError):
                self.book.rate_for(day)

    def test_supported_usd_formats_and_ambiguous_numbers(self):
        for text in ("USD 15.99", "US$15.99", "15.99 USD", "15.99달러", "미화15.99"):
            with self.subTest(text=text):
                self.assertEqual(usd_amount(text), Decimal("15.99"))
        for text in ("USD 1,2", "USD 0", "USD 15.99 USD 2"):
            with self.subTest(text=text), self.assertRaises(ValueError):
                usd_amount(text)
        self.assertIsNone(usd_amount("CAD 15.99"))

    def test_usd_approval_preserves_original_currency_and_is_classified(self):
        row = parse_message(self.sms, 2026, rates=self.book)
        self.assertEqual((row.amount, row.original_currency, row.original_amount, row.category), (21111, "USD", "15.99", "문화·구독"))
        self.assertEqual((row.fx_rate, row.fx_date, row.fx_source, row.fx_estimated), ("1320.25", "2025-10-03", URL, True))
        summary = summarize([row], "2025-10")
        self.assertEqual((summary["total"], summary["fx_estimated_count"]), (21111, 1))

    def test_usd_cancellation_is_negative_and_cumulative_krw_is_ignored(self):
        row = parse_message(self.sms.replace("해외승인", "해외승인취소") + " 누적1,000,000원", 2026, rates=self.book)
        self.assertEqual(row.amount, -21111)
        self.assertTrue(row.cancelled)

    def test_krw_plus_usd_and_no_rates_are_reviewed_not_double_counted(self):
        for text, book in ((self.sms + " 원화 21,000원", self.book), (self.sms, None)):
            with self.subTest(text=text), self.assertRaises(ValueError):
                parse_message(text, 2026, rates=book)
        rows, rejected = parse_messages(self.sms + "\n[Web발신]\n현대카드 승인 1,000원 10/05 09:00 가게", 2025)
        self.assertEqual((len(rows), len(rejected)), (1, 1))
        self.assertEqual(rows[0].amount, 1000)

    def test_foreign_transaction_fingerprint_does_not_change_with_rate(self):
        a = parse_message(self.sms, 2026, rates=self.book)
        b = parse_message(self.sms, 2026, rates=RateBook({"2025-10-03": "1500"}, "2025-10-03"))
        self.assertEqual(a.id, b.id)
        self.assertNotEqual(a.amount, b.amount)

    def test_local_import_and_default_loading_make_no_network_request(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "rates.json"
            xml = Path(directory) / "rates.xml"
            xml.write_bytes(XML)
            with patch("socket.socket", side_effect=AssertionError("network forbidden")), patch("urllib.request.urlopen", side_effect=AssertionError("network forbidden")):
                book = import_rates(xml, cache_path=path)
                self.assertEqual(load_rates(cache_path=path).rates, book.rates)
                self.assertEqual(load_rates(cache_path=path, offline=True).rates, book.rates)
            self.assertEqual(book.rates["2025-10-03"], "1320.000000")
            self.assertNotIn("NETFLIX", path.read_text())

    def test_offline_without_cache_makes_no_request(self):
        with tempfile.TemporaryDirectory() as directory, patch("socket.socket", side_effect=AssertionError("network forbidden")):
            with self.assertRaises(ValueError):
                load_rates(cache_path=Path(directory) / "missing.json", offline=True)

    def test_old_cache_is_used_without_refreshing_over_network(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "rates.json"
            path.write_text(json.dumps({"version": 1, "source": URL, "fetched_on": "2025-10-03", "rates": self.book.rates}), encoding="utf-8")
            with patch("socket.socket", side_effect=AssertionError("network forbidden")):
                book = load_rates(cache_path=path)
            self.assertEqual(book.rate_for("2025-10-05")[0], Decimal("1320.25"))

    def test_invalid_cache_is_rejected_and_missing_rates_do_not_become_zero(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "rates.json"
            path.write_text("[]", encoding="utf-8")
            with self.assertRaises(ValueError):
                load_rates(cache_path=path, offline=True)
            with patch("socket.socket", side_effect=AssertionError("network forbidden")), self.assertRaises(ValueError):
                load_rates(cache_path=path)

    def test_online_override_is_refused_before_any_network_operation(self):
        with patch("socket.socket", side_effect=AssertionError("network forbidden")), self.assertRaisesRegex(ValueError, "차단"):
            load_rates(offline=False)

    def test_fx_json_roundtrip_and_manual_billed_amount_override(self):
        row = parse_message(self.sms, 2026, rates=self.book)
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "ledger.json")
            save_ledger(path, [row])
            self.assertEqual(load_ledger(path), [row])
            save_ledger(path, [replace(row, amount=22000)])
            with self.assertRaises(ValueError):
                load_ledger(path)
            billed = replace(row, amount=22000, fx_estimated=False)
            save_ledger(path, [billed])
            self.assertEqual(load_ledger(path), [billed])
            self.assertEqual(reclassify_transactions([billed])[0].original_amount, "15.99")

    def test_original_currency_rate_and_estimate_label_exported(self):
        row = parse_message(self.sms, 2026, rates=self.book)
        with tempfile.TemporaryDirectory() as directory:
            csv = str(Path(directory) / "ledger.csv")
            xlsx = str(Path(directory) / "ledger.xlsx")
            export_csv(csv, [row])
            content = Path(csv).read_text(encoding="utf-8-sig")
            self.assertIn("USD,15.99,1320.25,2025-10-03,환율 추정", content)
            export_xlsx(xlsx, [row])
            with ZipFile(xlsx) as archive:
                sheet = archive.read("xl/worksheets/sheet1.xml").decode()
                for value in ("USD", "15.99", "1320.25", "2025-10-03", "환율 추정"):
                    self.assertIn(value, sheet)


if __name__ == "__main__":
    unittest.main()
