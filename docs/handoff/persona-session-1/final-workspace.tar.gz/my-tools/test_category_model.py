import json
import tempfile
import unittest
from dataclasses import asdict, replace
from pathlib import Path
from unittest.mock import patch

from category_model import LocalCategorizer
from ledger import (RULES, export_csv, load_ledger, parse_message,
                    reclassify_transactions, save_ledger, summarize)


class CategoryModelTests(unittest.TestCase):
    def row(self, merchant, **changes):
        row = parse_message(f"현대카드 승인 1,000원 10/01 10:00 {merchant}", 2026)
        return replace(row, **changes)

    def test_model_generalizes_beyond_old_keywords(self):
        model = LocalCategorizer(RULES)
        for name, category in (("파리바게뜨 강남점", "카페·간식"), ("왓챠", "문화·구독"),
                               ("아고다", "여행·숙박"), ("노브랜드", "식료품·생활")):
            with self.subTest(name=name):
                prediction = model.predict(name)
                self.assertEqual(prediction.category, category)
                self.assertEqual(prediction.method, "로컬 모델")
                self.assertFalse(prediction.needs_review)

    def test_unknown_names_are_not_confidently_assigned(self):
        prediction = LocalCategorizer(RULES).predict("주식회사새로운가맹점")
        self.assertEqual(prediction.category, "기타")
        self.assertTrue(prediction.needs_review)

    def test_marketplace_remains_reviewable_even_when_suggested_as_shopping(self):
        model = LocalCategorizer(RULES)
        for name in ("쿠팡", "네이버페이", "카카오페이", "토스페이"):
            with self.subTest(name=name):
                self.assertTrue(model.predict(name).needs_review)
        self.assertEqual(model.predict("쿠팡이츠").category, "식비·배달")
        self.assertFalse(model.predict("쿠팡이츠").needs_review)

    def test_confirmed_correction_overrides_default_and_survives_reclassification(self):
        confirmed = self.row("쿠팡", category="식료품·생활", category_confirmed=True, category_method="직접 확인")
        new = replace(self.row("쿠팡"), id="new")
        result = reclassify_transactions([confirmed, new])
        self.assertEqual(result[0], confirmed)
        self.assertEqual(result[1].category, "식료품·생활")
        self.assertEqual(result[1].category_method, "사용자 학습")
        self.assertFalse(result[1].category_confirmed)

    def test_similar_branch_gets_a_reviewable_personal_suggestion(self):
        model = LocalCategorizer(RULES, [("푸른달책방 강남점", "문화·구독")])
        exact = model.predict("푸른달책방 강남점")
        similar = model.predict("푸른달책방 역삼점")
        self.assertEqual(exact.method, "사용자 학습")
        self.assertEqual(similar.category, "문화·구독")
        self.assertTrue(similar.needs_review)
        self.assertGreater(exact.score, similar.score)

    def test_only_confirmed_rows_teach_model(self):
        automatic = self.row("푸른달책방 강남점", category="문화·구독", category_confirmed=False)
        new = self.row("푸른달책방 강남점", id="new")
        result = reclassify_transactions([new], training_rows=[automatic])
        self.assertEqual(result[0].category, "기타")
        self.assertEqual(result[0].category_method, "확인 필요")

    def test_conflicting_user_labels_require_review_for_future_rows(self):
        model = LocalCategorizer(RULES, [("쿠팡", "쇼핑"), ("쿠팡", "식료품·생활")])
        self.assertTrue(model.predict("쿠팡").needs_review)

    def test_repeated_purchase_does_not_change_model_weight(self):
        example = ("푸른달책방 강남점", "문화·구독")
        a = LocalCategorizer(RULES, [example]).predict("푸른달책방 역삼점")
        b = LocalCategorizer(RULES, [example] * 100).predict("푸른달책방 역삼점")
        self.assertEqual(a, b)

    def test_model_and_training_make_no_network_calls(self):
        with patch("socket.socket", side_effect=AssertionError("network forbidden")), patch("socket.create_connection", side_effect=AssertionError("network forbidden")):
            model = LocalCategorizer(RULES, [("푸른달책방 강남점", "문화·구독")])
            self.assertEqual(model.predict("푸른달책방 강남점").category, "문화·구독")
            self.assertEqual(model.predict("왓챠").category, "문화·구독")

    def test_reclassification_preserves_financial_fields_and_exclusion(self):
        rows = [self.row("쿠팡", id="one", amount=70000, excluded=True, exclusion_reason="확인 대기"),
                self.row("왓챠", id="two", amount=-1000, cancelled=True)]
        updated = reclassify_transactions(rows)
        for before, after in zip(rows, updated):
            for key in ("id", "date", "card", "merchant", "amount", "cancelled", "excluded", "exclusion_reason"):
                self.assertEqual(getattr(before, key), getattr(after, key))
        self.assertEqual(summarize(rows, "2026-10")["total"], summarize(updated, "2026-10")["total"])

    def test_saved_confirmations_restore_training_and_old_files_still_load(self):
        confirmed = self.row(
            "푸른달책방", category="문화·구독", category_confirmed=True, category_method="직접 확인", category_score=1.0)
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "ledger.json")
            save_ledger(path, [confirmed])
            restored = load_ledger(path)
            self.assertEqual(restored, [confirmed])
            predicted = reclassify_transactions([self.row("푸른달책방")], training_rows=restored)[0]
            self.assertEqual(predicted.category, "문화·구독")
            old = asdict(confirmed)
            for key in ("category_confirmed", "category_score", "category_method"):
                del old[key]
            Path(path).write_text(json.dumps({"version": 1, "transactions": [old]}), encoding="utf-8")
            self.assertFalse(load_ledger(path)[0].category_confirmed)

    def test_invalid_classification_metadata_is_rejected(self):
        for changes in ({"category_score": float("nan")}, {"category_score": 1.01},
                        {"category_confirmed": "yes"}, {"category_method": "unknown"}):
            with self.subTest(changes=changes), tempfile.TemporaryDirectory() as directory:
                path = str(Path(directory) / "ledger.json")
                save_ledger(path, [self.row("테스트가게", **changes)])
                with self.assertRaises(ValueError):
                    load_ledger(path)

    def test_review_metadata_is_exported_and_counted_without_dropping_purchase(self):
        row = self.row("쿠팡")
        self.assertEqual(summarize([row], "2026-10")["category_review_count"], 1)
        self.assertEqual(summarize([row], "2026-10")["total"], 1000)
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "export.csv")
            export_csv(path, [row])
            self.assertIn("확인 필요", Path(path).read_text(encoding="utf-8-sig"))


if __name__ == "__main__":
    unittest.main()
