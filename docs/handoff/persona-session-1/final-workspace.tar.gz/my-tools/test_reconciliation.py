import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from xml.etree import ElementTree as ET
from zipfile import ZipFile

from excel_export import SHEET_NS, export_xlsx
from ledger import Transaction, ledger_revision, load_ledger, save_ledger, summarize
from web_app import snapshot


class ReconciliationTests(unittest.TestCase):
    def rows(self):
        # Independently enumerated approvals/refund, not generated from summarize.
        amounts = [12000, -12000, 45800, 33000, 360000, 4500, 70000, 13200, 21450]
        return [Transaction(str(i), "2025-10-09T12:00", "검증카드", f"검증가맹점{i}", amount, "기타", amount < 0)
                for i, amount in enumerate(amounts)]

    def test_full_approval_and_refund_total_is_not_adjusted_to_a_target(self):
        result = summarize(self.rows(), "2025-10")
        self.assertEqual(result["recorded_approved"], 559950)
        self.assertEqual(result["recorded_cancelled"], 12000)
        self.assertEqual(result["recorded_total"], 547950)
        self.assertEqual(result["total"], 547950)
        self.assertEqual(result["recorded_count"], 9)

    def test_review_note_alone_never_excludes_a_payment(self):
        rows = self.rows()
        rows[6] = replace(rows[6], review_note="결제 상태 확인 필요")
        result = summarize(rows, "2025-10")
        self.assertEqual(result["total"], 547950)
        self.assertEqual(result["excluded_count"], 0)
        self.assertEqual(result["pending_review_count"], 1)

    def test_explicit_exclusion_preserves_raw_totals_and_explains_difference(self):
        rows = self.rows()
        rows[6] = replace(rows[6], excluded=True, exclusion_reason="사용자가 명시한 제외")
        result = summarize(rows, "2025-10")
        self.assertEqual(result["recorded_total"], 547950)
        self.assertEqual(result["excluded_amount"], 70000)
        self.assertEqual(result["total"], 477950)
        self.assertEqual(result["recorded_total"] - result["excluded_amount"], result["total"])

    def test_excluding_refund_also_reconciles_without_hiding_its_sign(self):
        rows = self.rows()
        rows[1] = replace(rows[1], excluded=True, exclusion_reason="확인 중")
        result = summarize(rows, "2025-10")
        self.assertEqual(result["recorded_cancelled"], 12000)
        self.assertEqual(result["excluded_amount"], -12000)
        self.assertEqual(result["total"], 559950)
        self.assertEqual(result["recorded_total"] - result["excluded_amount"], result["total"])

    def test_snapshot_and_excel_identify_same_data_and_preserve_review_note(self):
        rows = self.rows()
        rows[6] = replace(rows[6], review_note="승인 상태 확인 필요")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "ledger.json"
            excel = Path(directory) / "ledger.xlsx"
            save_ledger(str(path), rows)
            self.assertEqual(load_ledger(str(path)), rows)
            data = snapshot(path)
            export_xlsx(str(excel), rows)
            ns = {"s": SHEET_NS}
            with ZipFile(excel) as archive:
                sheet = ET.fromstring(archive.read("xl/worksheets/sheet1.xml"))
                version = sheet.find(".//s:c[@r='B17']/s:is/s:t", ns).text
                self.assertEqual(version, data["revision"])
                self.assertEqual(sheet.find(".//s:c[@r='B5']/s:v", ns).text, "547950")
                self.assertIn("승인 상태 확인 필요", archive.read("xl/worksheets/sheet1.xml").decode())
            self.assertEqual(data["months"][0]["total"], 547950)

    def test_version_detects_changed_exclusion_but_is_independent_of_row_order(self):
        rows = self.rows()
        self.assertEqual(ledger_revision(rows), ledger_revision(list(reversed(rows))))
        changed = [replace(row, excluded=True, exclusion_reason="직접 제외") if i == 6 else row for i, row in enumerate(rows)]
        self.assertNotEqual(ledger_revision(rows), ledger_revision(changed))


if __name__ == "__main__":
    unittest.main()
