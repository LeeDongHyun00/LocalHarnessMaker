import contextlib
import io
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from zipfile import ZipFile

import app
import web_app
from exchange_rates import import_rates, load_rates
from excel_export import export_xlsx
from ledger import export_csv, load_ledger, parse_messages, reclassify_transactions, save_ledger, summarize
from organize_downloads import apply, plan, undo


class OfflinePrivacyTests(unittest.TestCase):
    def test_finance_and_organizing_complete_without_network_or_dns(self):
        xml = b'<Envelope><Cube time="2025-10-03"><Cube currency="USD" rate="1.25"/><Cube currency="KRW" rate="1650"/></Cube></Envelope>'
        text = "현대카드 승인 1,000원 2025/10/03 09:00 GS25\n[Web발신]\n현대카드 해외승인 USD 2.50 2025/10/03 10:00 NETFLIX"
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source, cache = root / "rates.xml", root / "cache.json"
            source.write_bytes(xml)
            with patch("socket.socket", side_effect=AssertionError("network forbidden")), patch("socket.getaddrinfo", side_effect=AssertionError("DNS forbidden")), patch("socket.create_connection", side_effect=AssertionError("network forbidden")), patch("urllib.request.urlopen", side_effect=AssertionError("network forbidden")):
                import_rates(source, cache_path=cache)
                rates = load_rates(cache_path=cache)
                rows, rejected = parse_messages(text, 2025, rates=rates)
                self.assertEqual(rejected, [])
                rows = reclassify_transactions(rows)
                self.assertEqual(summarize(rows, "2025-10")["total"], 4300)
                json_path, excel, csv = root / "ledger.json", root / "ledger.xlsx", root / "ledger.csv"
                save_ledger(str(json_path), rows)
                self.assertEqual(load_ledger(str(json_path)), rows)
                export_csv(str(csv), rows)
                export_xlsx(str(excel), rows)
                with ZipFile(excel) as archive:
                    self.assertIsNone(archive.testzip())
                downloads = root / "downloads"
                downloads.mkdir()
                (downloads / "memo.txt").write_bytes(b"keep")
                apply(downloads, plan(downloads))
                self.assertEqual(undo(downloads), 1)
                self.assertEqual((downloads / "memo.txt").read_bytes(), b"keep")

    def test_old_online_and_lan_options_fail_before_prompt_or_connection(self):
        for main, argv in ((app.main, ["app.py", "--summary", "unused", "--fx-auto"]),
                           (web_app.main, ["web_app.py", "--lan"]),
                           (web_app.main, ["web_app.py", "--address", "192.168.1.2"])):
            with self.subTest(argv=argv), patch("sys.argv", argv), patch("socket.socket", side_effect=AssertionError("network forbidden")), patch("getpass.getpass", side_effect=AssertionError("must not prompt")), contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit) as error:
                    main()
                self.assertEqual(error.exception.code, 2)
