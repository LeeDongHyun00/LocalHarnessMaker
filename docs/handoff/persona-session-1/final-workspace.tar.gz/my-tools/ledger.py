"""Offline Korean card SMS parsing and local file formats (standard library only)."""
from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import re
import tempfile
from dataclasses import asdict, dataclass, replace
from datetime import datetime
from pathlib import Path
from functools import lru_cache
from decimal import Decimal, InvalidOperation

from category_model import LocalCategorizer
from exchange_rates import RateBook, URL as FX_SOURCE, convert_usd, usd_amount

CATEGORIES = ("식비·배달", "카페·간식", "쇼핑", "식료품·생활", "교통·차량", "의료·건강", "문화·구독", "여행·숙박", "기타")
RULES = (
    ("카페·간식", ("스타벅스", "투썸", "이디야", "메가커피", "컴포즈", "커피", "카페", "베이커리")),
    ("식비·배달", ("배달의민족", "배민", "요기요", "쿠팡이츠", "음식", "식당", "치킨", "피자", "버거", "김밥", "한식")),
    ("식료품·생활", ("이마트", "홈플러스", "롯데마트", "하나로마트", "편의점", "세븐일레븐", "씨유", "gs25", "다이소")),
    ("교통·차량", ("택시", "카카오t", "주유", "충전소", "주차", "철도", "코레일", "하이패스")),
    ("의료·건강", ("병원", "의원", "약국", "치과", "안과")),
    ("문화·구독", ("넷플릭스", "netflix", "유튜브", "youtube", "cgv", "메가박스", "롯데시네마", "서점", "교보문고", "spotify")),
    ("여행·숙박", ("호텔", "항공", "에어비앤비", "야놀자", "여기어때", "숙박")),
    ("쇼핑", ("쿠팡", "네이버페이", "무신사", "백화점", "지마켓", "11번가", "옥션")),
)
CARD = re.compile(
    r"(?:KB\s*국민|국민|신한|현대|삼성|롯데|하나|우리|비씨|BC|NH\s*농협|농협|기업|카카오뱅크|케이뱅크|토스뱅크)\s*(?:체크\s*)?카드"
    r"|(?P<woori_check>우리)\s*(?:\([0-9*•xX-]+\)\s*)?체크(?:\s*카드)?", re.I)
DATE = re.compile(r"(?<!\d)(?:(20\d{2})[./-])?(\d{1,2})[./-](\d{1,2})\s+(\d{1,2}):(\d{2})(?!\d)")


@dataclass
class Transaction:
    id: str
    date: str
    card: str
    merchant: str
    amount: int
    category: str
    cancelled: bool = False
    excluded: bool = False
    exclusion_reason: str = ""
    category_confirmed: bool = False
    category_score: float = 0.0
    category_method: str = "기존 분류"
    original_currency: str = "KRW"
    original_amount: str = ""
    fx_rate: str = ""
    fx_date: str = ""
    fx_source: str = ""
    fx_estimated: bool = False
    review_note: str = ""


@dataclass
class Rejected:
    text: str
    reason: str


def categorize(merchant: str) -> str:
    return default_categorizer().predict(merchant).category


@lru_cache(maxsize=1)
def default_categorizer() -> LocalCategorizer:
    return LocalCategorizer(RULES)


def reclassify_transactions(rows: list[Transaction], *, training_rows: list[Transaction] | None = None) -> list[Transaction]:
    examples = rows if training_rows is None else training_rows
    model = LocalCategorizer(RULES, [(row.merchant, row.category) for row in examples if row.category_confirmed])
    updated = []
    for row in rows:
        if row.category_confirmed:
            updated.append(row)
            continue
        prediction = model.predict(row.merchant)
        updated.append(replace(row, category=prediction.category, category_score=prediction.score,
                               category_method=prediction.method))
    return updated


def split_messages(text: str) -> list[str]:
    # A marker or a new line beginning with a card issuer starts a new message.
    marked = re.sub(r"\[\s*Web\s*발신\s*\]", "\n\x00", text, flags=re.I)
    issuer = CARD.pattern
    marked = re.sub(rf"(?m)^(?=\s*(?:{issuer}))", "\x00", marked)
    return [part.strip() for part in marked.split("\x00") if part.strip()]


def parse_message(text: str, year: int, *, rates: RateBook | None = None) -> Transaction:
    if not 1900 <= year <= 2100:
        raise ValueError("연도는 1900~2100 범위여야 합니다.")
    card = CARD.search(text)
    if not card or not re.search(r"승인|취소", text):
        raise ValueError("지원하는 카드사의 승인·취소 문자가 아닙니다.")
    if re.search(r"거절|실패|취소\s*(?:거절|불가|실패)|승인\s*예정", text):
        raise ValueError("실제 승인·취소가 아닌 안내입니다.")
    stamp = DATE.search(text)
    if not stamp:
        raise ValueError("결제 날짜와 시간(MM/DD HH:MM)을 찾지 못했습니다.")
    explicit_year, month, day, hour, minute = stamp.groups()
    try:
        date = datetime(int(explicit_year or year), int(month), int(day), int(hour), int(minute))
    except ValueError as exc:
        raise ValueError("존재하지 않는 날짜 또는 시간입니다.") from exc
    # Cumulative totals are never treated as a purchase amount.
    clean = re.sub(r"(?:누적|잔액|이용한도)[\s:]*[\d,]+\s*원", "", text)
    if re.search(r"\b(?:EUR|JPY|CNY|GBP|CAD|AUD|HKD|SGD)\s*\d", clean, re.I):
        raise ValueError("현재 자동 환산은 USD만 지원합니다. 다른 통화는 직접 확인해 주세요.")
    amounts = list(re.finditer(r"(?<![\d,.])([1-9]\d*(?:,\d{3})*|0)\s*원", clean))
    dollars = usd_amount(clean)
    foreign = {}
    if dollars is not None:
        if amounts:
            raise ValueError("원화·달러 금액이 함께 있어 중복 합산 방지를 위해 확인이 필요합니다.")
        if rates is None:
            raise ValueError("USD 결제는 로컬 환율 자료가 필요합니다. 환율 XML을 가져오거나 원화 청구액을 직접 입력해 주세요.")
        amount, rate, rate_date = convert_usd(dollars, date.date().isoformat(), rates)
        foreign = dict(original_currency="USD", original_amount=str(dollars), fx_rate=rate,
                       fx_date=rate_date, fx_source=FX_SOURCE, fx_estimated=True)
    elif len(amounts) != 1:
        raise ValueError("원화 결제금액을 하나로 확정할 수 없습니다. 외화·복수 금액은 직접 확인해 주세요.")
    else:
        amount = int(amounts[0].group(1).replace(",", ""))
    if amount <= 0:
        raise ValueError("결제금액이 0원입니다.")
    merchant = text[stamp.end():]
    merchant = re.split(r"누적|잔액|이용한도", merchant, maxsplit=1)[0].strip()
    merchant = re.sub(r"\s+", " ", merchant)
    if not merchant or re.search(r"\d\s*원|https?://", merchant):
        raise ValueError("날짜 뒤의 가맹점 이름을 확인할 수 없습니다.")
    cancelled = bool(re.search(r"취소", text[:stamp.start()]))
    fingerprint = hashlib.sha256((date.isoformat() + re.sub(r"\s+", "", text)).encode()).hexdigest()
    # Some Woori debit SMS omit '카드' and embed masked digits before '체크'.
    card_label = "우리체크카드" if card.group("woori_check") else re.sub(r"\s+", "", card.group())
    prediction = default_categorizer().predict(merchant)
    return Transaction(fingerprint, date.isoformat(timespec="minutes"),
                       card_label, merchant,
                       -amount if cancelled else amount, prediction.category, cancelled,
                       category_score=prediction.score, category_method=prediction.method, **foreign)


def parse_messages(text: str, year: int, *, rates: RateBook | None = None) -> tuple[list[Transaction], list[Rejected]]:
    accepted, rejected = [], []
    for block in split_messages(text):
        try:
            accepted.append(parse_message(block, year, rates=rates))
        except ValueError as exc:
            rejected.append(Rejected(block, str(exc)))
    return accepted, rejected


def summarize(transactions: list[Transaction], month: str) -> dict:
    monthly = [row for row in transactions if row.date.startswith(month + "-")]
    rows = [row for row in monthly if not row.excluded]
    excluded = [row for row in monthly if row.excluded]
    categories = {category: sum(row.amount for row in rows if row.category == category) for category in CATEGORIES}
    return {"month": month, "count": len(rows), "approved": sum(row.amount for row in rows if row.amount > 0),
            "cancelled": -sum(row.amount for row in rows if row.amount < 0),
            "total": sum(row.amount for row in rows), "categories": categories,
            "excluded_count": len(excluded), "excluded_amount": sum(row.amount for row in excluded),
            "category_review_count": sum(row.category_method == "확인 필요" for row in rows),
            "fx_estimated_count": sum(row.fx_estimated for row in rows),
            "recorded_count": len(monthly),
            "recorded_approved": sum(row.amount for row in monthly if row.amount > 0),
            "recorded_cancelled": -sum(row.amount for row in monthly if row.amount < 0),
            "recorded_total": sum(row.amount for row in monthly),
            "pending_review_count": sum(bool(row.review_note) for row in monthly)}


def ledger_revision(rows: list[Transaction]) -> str:
    """Stable identifier for comparing saved data and exported snapshots."""
    contents = json.dumps([asdict(row) for row in sorted(rows, key=lambda row: row.id)],
                          ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(contents.encode("utf-8")).hexdigest()[:12]


def save_ledger(path: str, rows: list[Transaction]) -> None:
    # Deliberately omit original SMS, card digits and cardholder names.
    contents = json.dumps({"version": 1, "transactions": [asdict(row) for row in rows]},
                          ensure_ascii=False, indent=2)
    destination = Path(path).absolute()
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=destination.parent,
                                         prefix=".card-ledger-", suffix=".tmp", delete=False) as file:
            temporary = Path(file.name)
            file.write(contents)
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary, destination)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def load_ledger(path: str) -> list[Transaction]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(data, dict) or data.get("version") != 1 or not isinstance(data.get("transactions"), list):
        raise ValueError("지원하지 않는 저장 파일입니다.")
    rows = []
    for item in data["transactions"]:
        row = Transaction(**item)
        if (not all(isinstance(v, str) for v in (row.id, row.date, row.card, row.merchant, row.category))
                or not row.id or not row.merchant.strip() or type(row.amount) is not int or row.amount == 0
                or type(row.cancelled) is not bool or row.cancelled != (row.amount < 0)
                or type(row.excluded) is not bool or not isinstance(row.exclusion_reason, str)
                or (row.excluded and not row.exclusion_reason.strip())
                or type(row.category_confirmed) is not bool
                or type(row.category_score) not in (int, float) or not math.isfinite(row.category_score)
                or not 0 <= row.category_score <= 1
                or row.category_method not in ("기존 분류", "사용자 학습", "키워드", "로컬 모델", "확인 필요", "직접 확인")
                or not isinstance(row.review_note, str)
                or row.category not in CATEGORIES):
            raise ValueError("올바르지 않은 거래가 들어 있습니다.")
        if datetime.fromisoformat(row.date).isoformat(timespec="minutes") != row.date:
            raise ValueError("날짜는 YYYY-MM-DDTHH:MM 형식이어야 합니다.")
        if row.original_currency not in ("KRW", "USD") or type(row.fx_estimated) is not bool:
            raise ValueError("외화 내역 형식이 올바르지 않습니다.")
        if not all(isinstance(value, str) for value in (row.original_amount, row.fx_rate, row.fx_date, row.fx_source)):
            raise ValueError("환산 정보 형식이 올바르지 않습니다.")
        if row.original_currency == "USD":
            try:
                original, rate = Decimal(row.original_amount), Decimal(row.fx_rate)
                if not original.is_finite() or not rate.is_finite() or original <= 0 or rate <= 0:
                    raise ValueError
                if row.fx_source != FX_SOURCE or not row.fx_date or row.fx_date > row.date[:10]:
                    raise ValueError
                datetime.strptime(row.fx_date, "%Y-%m-%d")
                if row.fx_estimated:
                    from decimal import ROUND_HALF_UP
                    expected = int((original * rate).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
                    if abs(row.amount) != expected:
                        raise ValueError
            except (InvalidOperation, ValueError):
                raise ValueError("외화 환산 정보가 유효하지 않습니다.") from None
        elif row.fx_estimated or any((row.original_amount, row.fx_rate, row.fx_date, row.fx_source)):
            raise ValueError("원화 거래에 외화 환산 정보가 들어 있습니다.")
        rows.append(row)
    if len({row.id for row in rows}) != len(rows):
        raise ValueError("중복 ID가 들어 있는 파일입니다.")
    return rows


def export_csv(path: str, rows: list[Transaction]) -> None:
    def safe(value: str) -> str:
        # Prevent spreadsheet formula execution when opening exported text.
        return "'" + value if value.lstrip().startswith(("=", "+", "-", "@")) else value
    with open(path, "w", newline="", encoding="utf-8-sig") as file:
        writer = csv.writer(file)
        writer.writerow(["일시", "카드", "가맹점", "금액(원)", "카테고리", "구분", "집계 반영액(원)", "집계 상태", "제외 사유", "분류 상태",
                         "원통화", "원거래금액(절댓값)", "적용환율(원/USD)", "환율 기준일", "금액 상태", "환율 출처", "확인 메모"])
        for row in rows:
            writer.writerow([safe(row.date), safe(row.card), safe(row.merchant), row.amount,
                             safe(row.category), "취소" if row.cancelled else "승인",
                             0 if row.excluded else row.amount, "제외" if row.excluded else "포함", safe(row.exclusion_reason), safe(row.category_method),
                             row.original_currency, row.original_amount if row.original_currency == "USD" else abs(row.amount),
                             row.fx_rate, row.fx_date, "환율 추정" if row.fx_estimated else "직접 입력" if row.original_currency == "USD" else "원화 승인", safe(row.fx_source), safe(row.review_note)])
