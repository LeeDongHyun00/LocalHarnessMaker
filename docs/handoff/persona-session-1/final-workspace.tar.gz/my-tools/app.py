"""Run `python app.py` for the desktop app; no server or network access."""
from __future__ import annotations

import argparse
import json
import sys
import uuid
from dataclasses import replace
from datetime import datetime
from pathlib import Path

from excel_export import export_xlsx
from exchange_rates import USD, load_rates
from ledger import (CATEGORIES, Transaction, export_csv, load_ledger, parse_messages,
                    reclassify_transactions, save_ledger, summarize)


def run_gui() -> None:
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox, ttk
    except ImportError:
        raise SystemExit("Tkinter가 필요합니다. Windows/macOS는 Python 공식 설치본을, "
                         "Ubuntu/Debian은 python3-tk 패키지를 설치해 주세요. README.md를 참고하세요.")

    class App:
        def __init__(self, root):
            self.root = root
            self.rows: list[Transaction] = []
            self.dirty = False
            root.title("내 카드 가계부 · 오프라인")
            root.geometry("1120x860")
            root.minsize(900, 700)
            root.protocol("WM_DELETE_WINDOW", self.close)
            style = ttk.Style()
            style.configure("TButton", padding=5)
            style.configure("Treeview", rowheight=26)
            outer = ttk.Frame(root, padding=16)
            outer.pack(fill="both", expand=True)
            ttk.Label(outer, text="내 카드 가계부", font=("", 21, "bold")).pack(anchor="w")
            ttk.Label(outer, text="외부 통신 없음 · 로컬 분류 · 저장된 환율만 사용 · 내역은 저장할 때만 기록").pack(anchor="w", pady=(4, 10))

            toolbar = ttk.Frame(outer)
            toolbar.pack(fill="x")
            for label, action in (("파일 열기", self.open_file), ("전체 저장", self.save),
                                  ("월별 엑셀", self.export_excel), ("선택 월 CSV", self.export), ("전체 비우기", self.clear)):
                ttk.Button(toolbar, text=label, command=action).pack(side="left", padx=(0, 6))
            ttk.Label(toolbar, text="문자에 연도가 없을 때:").pack(side="left", padx=(14, 4))
            self.year = tk.StringVar(value=str(datetime.now().year))
            ttk.Spinbox(toolbar, from_=1900, to=2100, textvariable=self.year, width=6).pack(side="left")

            ttk.Label(outer, text="카드 문자 붙여넣기 (여러 건을 한 번에 붙여넣을 수 있어요)").pack(anchor="w", pady=(12, 4))
            self.input = tk.Text(outer, height=7, wrap="word", undo=False)
            self.input.pack(fill="x")
            controls = ttk.Frame(outer)
            controls.pack(fill="x", pady=6)
            self.analyze_button = ttk.Button(controls, text="분석해서 추가", command=self.analyze)
            self.analyze_button.pack(side="left")
            ttk.Button(controls, text="입력 지우기", command=lambda: self.input.delete("1.0", "end")).pack(side="left", padx=6)
            self.allow_duplicate = tk.BooleanVar(value=False)
            ttk.Checkbutton(controls, text="동일 문자도 별도 추가", variable=self.allow_duplicate).pack(side="left", padx=6)
            self.status = tk.StringVar(value="문자를 붙여넣고 ‘분석해서 추가’를 눌러 주세요.")
            ttk.Label(outer, textvariable=self.status, wraplength=1000).pack(anchor="w")

            monthbar = ttk.Frame(outer)
            monthbar.pack(fill="x", pady=(12, 6))
            ttk.Label(monthbar, text="조회 월").pack(side="left")
            self.month = tk.StringVar(value=datetime.now().strftime("%Y-%m"))
            self.monthbox = ttk.Combobox(monthbar, textvariable=self.month, state="readonly", width=10)
            self.monthbox.pack(side="left", padx=8)
            self.monthbox.bind("<<ComboboxSelected>>", lambda event: self.refresh())
            self.total = tk.StringVar()
            ttk.Label(monthbar, textvariable=self.total, font=("", 12, "bold"), wraplength=820).pack(side="left", padx=10)

            categories = ttk.Frame(outer)
            categories.pack(fill="x", pady=(0, 8))
            self.category_labels = {}
            self.category_bars = {}
            for i, name in enumerate(CATEGORIES):
                frame = ttk.Frame(categories, padding=(0, 3, 16, 3))
                frame.grid(row=i // 3, column=i % 3, sticky="ew")
                categories.columnconfigure(i % 3, weight=1)
                label = ttk.Label(frame)
                label.pack(anchor="w")
                bar = ttk.Progressbar(frame, maximum=100)
                bar.pack(fill="x")
                self.category_labels[name] = label
                self.category_bars[name] = bar

            tableframe = ttk.Frame(outer)
            tableframe.pack(fill="both", expand=True)
            columns = ("date", "card", "merchant", "amount", "category", "kind", "classification")
            self.table = ttk.Treeview(tableframe, columns=columns, show="headings", height=8)
            for key, title, width in zip(columns, ("일시", "카드", "가맹점", "금액(원)", "카테고리", "구분", "분류 상태"),
                                         (145, 100, 220, 100, 120, 95, 110)):
                self.table.heading(key, text=title)
                self.table.column(key, width=width, anchor="e" if key == "amount" else "w")
            scroll = ttk.Scrollbar(tableframe, orient="vertical", command=self.table.yview)
            self.table.configure(yscrollcommand=scroll.set)
            self.table.pack(side="left", fill="both", expand=True)
            scroll.pack(side="right", fill="y")
            self.table.tag_configure("cancelled", foreground="#b42318")
            self.table.tag_configure("excluded", foreground="#777777")
            self.table.bind("<Double-1>", lambda event: self.edit())
            actions = ttk.Frame(outer)
            actions.pack(fill="x", pady=6)
            ttk.Button(actions, text="선택 내역 수정", command=self.edit).pack(side="left")
            ttk.Button(actions, text="직접 추가", command=lambda: self.editor()).pack(side="left", padx=6)
            ttk.Button(actions, text="선택 삭제", command=self.delete).pack(side="left")
            ttk.Button(actions, text="로컬 AI로 다시 분류", command=self.reclassify).pack(side="left", padx=6)
            self.review_only = tk.BooleanVar(value=False)
            ttk.Checkbutton(actions, text="분류 확인 필요만", variable=self.review_only, command=self.refresh).pack(side="left")
            ttk.Label(outer, text="합계 = 승인 − 취소. 취소는 문자 날짜의 월에 반영합니다. 할부도 승인 총액 기준입니다.\n"
                      "로컬 모델과 직접 확인한 분류로 학습합니다. ‘확인 필요’는 수정창에서 분류를 확정해 주세요.",
                      wraplength=1000).pack(anchor="w")

            self.errors = tk.Text(outer, height=3, wrap="word", state="disabled")
            self.errors.pack(fill="x", pady=(6, 0))
            self.refresh()

        def set_errors(self, text):
            self.errors.configure(state="normal")
            self.errors.delete("1.0", "end")
            self.errors.insert("1.0", text)
            self.errors.configure(state="disabled")

        def refresh(self):
            months = sorted({row.date[:7] for row in self.rows}, reverse=True)
            self.monthbox["values"] = months or [datetime.now().strftime("%Y-%m")]
            if self.month.get() not in self.monthbox["values"]:
                self.month.set(self.monthbox["values"][0])
            summary = summarize(self.rows, self.month.get())
            self.total.set(f"전체 승인 {summary['recorded_approved']:,} − 취소 {summary['recorded_cancelled']:,} − 제외 ({summary['excluded_amount']:,}) = {summary['total']:,}원\n전체 {summary['recorded_count']}건 · 집계 {summary['count']}건 · 내역 메모 {summary['pending_review_count']}건 · 분류 확인 {summary['category_review_count']}건 · 환산 추정 {summary['fx_estimated_count']}건")
            maximum = max([abs(value) for value in summary["categories"].values()] + [1])
            for name, value in summary["categories"].items():
                self.category_labels[name].configure(text=f"{name}  {value:,}원")
                self.category_bars[name]["value"] = abs(value) / maximum * 100
            self.table.delete(*self.table.get_children())
            for row in sorted(self.rows, key=lambda row: row.date, reverse=True):
                if row.date.startswith(self.month.get() + "-"):
                    if self.review_only.get() and row.category_method != "확인 필요":
                        continue
                    self.table.insert("", "end", iid=row.id, values=(row.date.replace("T", " "), row.card,
                                      row.merchant, f"{row.amount:,}", row.category,
                                      ("제외·" if row.excluded else "") + ("취소" if row.cancelled else "승인") + ("·추정" if row.fx_estimated else "") + ("·메모" if row.review_note else ""), row.category_method),
                                      tags=("excluded",) if row.excluded else ("cancelled",) if row.cancelled else ())
            self.root.title("내 카드 가계부 · 오프라인" + (" · 저장 안 됨" if self.dirty else ""))

        def analyze(self):
            try:
                year = int(self.year.get())
                if not 1900 <= year <= 2100:
                    raise ValueError
            except ValueError:
                messagebox.showerror("연도 확인", "1900~2100 사이의 연도를 입력해 주세요.")
                return
            text = self.input.get("1.0", "end")
            if not USD.search(text):
                self.finish_analysis(text, year)
                return
            try:
                book = load_rates()
                notice = "저장된 로컬 환율로 환산했습니다."
            except ValueError as exc:
                book, notice = None, str(exc)
            self.finish_analysis(text, year, rates=book, notice=notice)

        def finish_analysis(self, text, year, rates=None, notice=""):
            parsed, rejected = parse_messages(text, year, rates=rates)
            parsed = reclassify_transactions(parsed, training_rows=self.rows)
            known = {row.id for row in self.rows}
            added, duplicates = 0, 0
            for row in parsed:
                if row.id in known:
                    if not self.allow_duplicate.get():
                        duplicates += 1
                        continue
                    row.id = uuid.uuid4().hex
                known.add(row.id)
                self.rows.append(row)
                added += 1
            self.dirty = self.dirty or bool(added)
            if added:
                self.month.set(parsed[0].date[:7])
            self.status.set(f"{added}건 추가 · 동일 문자 {duplicates}건 제외 · 확인 필요 {len(rejected)}건. "
                            "같은 문자를 재추가할 때만 중복을 제외합니다. " + notice)
            self.set_errors("\n\n".join(f"확인 필요: {item.reason}\n{item.text}" for item in rejected)
                            or "해석하지 못한 문자가 없습니다.")
            self.refresh()

        def edit(self):
            selected = self.table.selection()
            if selected:
                self.editor(next(row for row in self.rows if row.id == selected[0]))

        def reclassify(self):
            updated = reclassify_transactions(self.rows)
            changed = sum(old != new for old, new in zip(self.rows, updated))
            self.rows = updated
            self.dirty = self.dirty or bool(changed)
            review = sum(row.category_method == "확인 필요" for row in self.rows)
            self.status.set(f"로컬 재분류 완료 · {changed}건 갱신 · 전체 분류 확인 필요 {review}건. 직접 확정한 분류는 유지됩니다.")
            self.refresh()

        def editor(self, row=None):
            dialog = tk.Toplevel(self.root)
            dialog.title("내역 수정" if row else "직접 추가")
            dialog.transient(self.root)
            dialog.grab_set()
            defaults = (row.date.replace("T", " "), row.card, row.merchant, str(abs(row.amount)), row.category) if row else (
                self.month.get() + "-01 12:00", "직접 입력", "", "", "기타")
            fields = []
            confirmed = tk.BooleanVar(value=row.category_confirmed if row else False)
            for i, (label, value) in enumerate(zip(("일시 (YYYY-MM-DD HH:MM)", "카드", "가맹점", "금액 (양수, 원)", "카테고리"), defaults)):
                ttk.Label(dialog, text=label).grid(row=i, column=0, padx=12, pady=7, sticky="w")
                var = tk.StringVar(value=value)
                widget = ttk.Combobox(dialog, textvariable=var, values=CATEGORIES, state="readonly") if i == 4 else ttk.Entry(dialog, textvariable=var, width=32)
                widget.grid(row=i, column=1, padx=12, pady=7)
                if i == 4:
                    widget.bind("<<ComboboxSelected>>", lambda event: confirmed.set(True))
                fields.append(var)
            cancelled = tk.BooleanVar(value=row.cancelled if row else False)
            ttk.Checkbutton(dialog, text="취소 내역 (합계에서 차감)", variable=cancelled).grid(row=5, column=1, sticky="w")
            excluded = tk.BooleanVar(value=row.excluded if row else False)
            reason = tk.StringVar(value=row.exclusion_reason if row else "")
            ttk.Checkbutton(dialog, text="집계 제외 (원래 내역은 보관)", variable=excluded).grid(row=6, column=1, sticky="w")
            ttk.Label(dialog, text="제외 사유").grid(row=7, column=0, padx=12, pady=7, sticky="w")
            ttk.Entry(dialog, textvariable=reason, width=32).grid(row=7, column=1, padx=12, pady=7)
            review = tk.StringVar(value=row.review_note if row else "")
            ttk.Label(dialog, text="확인 메모 (집계 영향 없음)").grid(row=11, column=0, padx=12, pady=7, sticky="w")
            ttk.Entry(dialog, textvariable=review, width=32).grid(row=11, column=1, padx=12, pady=7)
            ttk.Checkbutton(dialog, text="이 분류를 확정하고 학습에 반영", variable=confirmed).grid(row=8, column=1, sticky="w")
            ttk.Label(dialog, text="분류를 바꾸면 자동으로 체크됩니다. 학습 내용은 전체 저장에 함께 보관합니다.", wraplength=400).grid(row=9, column=0, columnspan=2, padx=12, pady=7)
            if row and row.original_currency == "USD":
                ttk.Label(dialog, text=f"원거래 USD {row.original_amount} · 1달러 {row.fx_rate}원 ({row.fx_date})\n"
                          "금액은 원화입니다. 카드 청구액으로 고치면 추정 표시를 해제합니다.", wraplength=450).grid(row=10, column=0, columnspan=2, padx=12, pady=7)

            def commit():
                try:
                    stamp = datetime.strptime(fields[0].get().strip(), "%Y-%m-%d %H:%M")
                    amount = int(fields[3].get().replace(",", ""))
                    if amount <= 0 or not fields[1].get().strip() or not fields[2].get().strip():
                        raise ValueError
                except ValueError:
                    messagebox.showerror("입력 확인", "유효한 일시, 카드, 가맹점, 0보다 큰 정수 금액을 입력해 주세요.", parent=dialog)
                    return
                if excluded.get() and not reason.get().strip():
                    messagebox.showerror("제외 사유 확인", "집계에서 제외하는 이유를 입력해 주세요.", parent=dialog)
                    return
                updated = Transaction(row.id if row else uuid.uuid4().hex, stamp.isoformat(timespec="minutes"),
                                      fields[1].get().strip(), fields[2].get().strip(),
                                      -amount if cancelled.get() else amount, fields[4].get(), cancelled.get(),
                                      excluded.get(), reason.get().strip() if excluded.get() else "",
                                      category_confirmed=confirmed.get(), category_score=1.0 if confirmed.get() else 0.0,
                                      category_method="직접 확인" if confirmed.get() else "확인 필요", review_note=review.get().strip())
                if row and row.original_currency == "USD":
                    updated = replace(updated, original_currency=row.original_currency, original_amount=row.original_amount,
                                      fx_rate=row.fx_rate, fx_date=row.fx_date, fx_source=row.fx_source,
                                      fx_estimated=row.fx_estimated and amount == abs(row.amount))
                if row:
                    self.rows[self.rows.index(row)] = updated
                else:
                    self.rows.append(updated)
                self.rows = reclassify_transactions(self.rows)
                self.dirty = True
                self.month.set(updated.date[:7])
                self.refresh()
                dialog.destroy()
            ttk.Button(dialog, text="적용", command=commit).grid(row=12, column=1, pady=14)

        def delete(self):
            selected = set(self.table.selection())
            if selected and messagebox.askyesno("선택 삭제", f"선택한 {len(selected)}건을 삭제할까요?"):
                self.rows = [row for row in self.rows if row.id not in selected]
                self.dirty = True
                self.refresh()

        def discard_ok(self):
            return not self.dirty or messagebox.askyesno("저장하지 않은 내역", "저장하지 않은 변경사항이 있습니다. 버리고 계속할까요?")

        def clear(self):
            if messagebox.askyesno("전체 비우기", "현재 내역과 입력 문자를 모두 비울까요? 저장하지 않은 내역은 사라집니다."):
                self.rows.clear()
                self.input.delete("1.0", "end")
                self.set_errors("")
                self.dirty = False
                self.status.set("모든 내역과 입력 문자를 비웠습니다.")
                self.refresh()

        def save(self):
            path = filedialog.asksaveasfilename(title="전체 내역을 로컬 JSON으로 저장", defaultextension=".json", filetypes=[("가계부 JSON", "*.json")])
            if path:
                try:
                    save_ledger(path, self.rows)
                except OSError as exc:
                    messagebox.showerror("저장 실패", str(exc))
                    return
                self.dirty = False
                self.status.set("전체 내역을 저장했습니다. 파일에는 가맹점·금액·날짜 등이 평문으로 들어 있습니다.")
                self.refresh()

        def open_file(self):
            path = filedialog.askopenfilename(filetypes=[("가계부 JSON", "*.json")])
            if not path:
                return
            try:
                rows = load_ledger(path)
            except (OSError, ValueError, TypeError, KeyError) as exc:
                messagebox.showerror("파일 열기 실패", f"올바른 가계부 파일인지 확인해 주세요.\n{exc}")
                return
            if not self.discard_ok():
                return
            self.rows, self.dirty = rows, False
            self.input.delete("1.0", "end")
            self.set_errors("")
            self.status.set(f"로컬 파일에서 {len(rows)}건을 열었습니다.")
            self.refresh()

        def export(self):
            rows = [row for row in self.rows if row.date.startswith(self.month.get() + "-")]
            path = filedialog.asksaveasfilename(title="선택 월 CSV 내보내기", initialfile=f"card-{self.month.get()}.csv", defaultextension=".csv", filetypes=[("CSV", "*.csv")])
            if path:
                try:
                    export_csv(path, rows)
                except OSError as exc:
                    messagebox.showerror("내보내기 실패", str(exc))
                    return
                self.status.set(f"{self.month.get()} 내역 {len(rows)}건을 CSV로 내보냈습니다. 전체 저장은 별도로 눌러 주세요.")

        def export_excel(self):
            if not self.rows:
                messagebox.showinfo("월별 엑셀", "먼저 문자를 분석하거나 파일을 열어 주세요.")
                return
            path = filedialog.asksaveasfilename(title="전체 내역을 월별 시트로 내보내기", initialfile="카드내역.xlsx",
                                              defaultextension=".xlsx", filetypes=[("Excel 통합 문서", "*.xlsx")])
            if path:
                try:
                    export_xlsx(path, self.rows)
                except (OSError, ValueError) as exc:
                    messagebox.showerror("엑셀 내보내기 실패", str(exc))
                    return
                count = len({row.date[:7] for row in self.rows})
                self.status.set(f"전체 {len(self.rows)}건을 월별 시트 {count}개로 내보냈습니다. JSON 전체 저장은 별도로 눌러 주세요.")

        def close(self):
            if self.discard_ok():
                self.root.destroy()

    try:
        root = tk.Tk()
    except tk.TclError:
        raise SystemExit("화면을 열 수 없습니다. 데스크톱 환경에서 실행하거나 --summary 옵션을 이용해 주세요.")
    App(root)
    root.mainloop()


def main():
    parser = argparse.ArgumentParser(description="외부 전송 없는 카드 문자 가계부")
    parser.add_argument("--summary", metavar="SMS_FILE", help="GUI 없이 로컬 문자 파일을 분석")
    parser.add_argument("--year", type=int, default=datetime.now().year, help="연도 없는 문자에 적용할 연도")
    parser.add_argument("--fx-offline", action="store_true", help="저장된 환율 사용 (기본 동작)")
    parser.add_argument("--ledger", metavar="JSON_FILE", help="기존 저장 내역·분류·집계 제외 설정을 유지하며 합산")
    args = parser.parse_args()
    if not args.summary:
        run_gui()
        return
    if not 1900 <= args.year <= 2100:
        parser.error("연도는 1900~2100 범위여야 합니다.")
    try:
        text = Path(args.summary).read_text(encoding="utf-8-sig")
        rates = None
        if USD.search(text):
            try:
                rates = load_rates()
            except ValueError:
                pass
        existing = load_ledger(args.ledger) if args.ledger else []
        rows, rejected = parse_messages(text, args.year, rates=rates)
        rows = reclassify_transactions(rows, training_rows=existing)
    except (OSError, ValueError, TypeError, KeyError) as exc:
        parser.error(str(exc))
    unique = list({row.id: row for row in rows}.values())
    combined = {row.id: row for row in unique}
    combined.update({row.id: row for row in existing})
    combined_rows = list(combined.values())
    print(json.dumps({"months": [summarize(combined_rows, month) for month in sorted({row.date[:7] for row in combined_rows})],
                      "duplicates": len(rows) - len(unique),
                      "needs_review": [item.reason for item in rejected]}, ensure_ascii=False, indent=2))
    if rejected:
        sys.exit(1)


if __name__ == "__main__":
    main()
